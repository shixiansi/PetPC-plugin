/**
 * QQ 群聊插件 —— Milky 协议桥。
 *
 * WHAT THIS FILE IS
 *
 * One plugin, two appearances of one document (see panel.html). The frame the pet
 * mounts in the background is the whole bot:
 *
 *   Milky 协议端 (Yogurt)  ──ws──▶ 宿主 (net.ws)  ──event──▶  这个文件
 *                                                             │
 *        llm.chat（借用对话插件的模型配置）◀───────────────────┤
 *                                                             │
 *        net.fetch POST /api/send_group_message ─────────────▶ 群里
 *
 * Nothing here talks to the network directly. The socket is the host's (a browser
 * `new WebSocket()` cannot send the `Authorization` header, and the page is torn
 * down on every plugin update), and the model is the host's (the credential never
 * enters this document). This file owns three things in return:
 *
 *   1. what counts as "talking to the bot" (a mention, or a configured prefix);
 *   2. what the model is told about the group (persona, the speaker, recent turns);
 *   3. what is remembered per group, in the plugin's own private storage.
 *
 * WHY THE HISTORY IS STORED HERE
 *
 * Per group, in `plugin-data/com.shixiansi.plugin-qq/hist_<群号>`. The host keeps
 * no transcript for plugin calls at all (that is the conversation plugin's file),
 * so a group's memory cannot live anywhere else without becoming a second, and
 * invisible, writer of it. The file is re-read before every answer instead of being
 * cached for the session, because the workshop view in the market program can CLEAR
 * a group's memory in a different process - a cached copy would quietly restore what
 * the user just deleted.
 */

'use strict';

// --- DOM ---------------------------------------------------------------------

const els = {
  root: document.getElementById('root'),
  background: document.getElementById('background'),
  workshop: document.getElementById('workshop'),
  chipState: document.getElementById('chip-state'),
  chipSelf: document.getElementById('chip-self'),
  chipModel: document.getElementById('chip-model'),
  statusNote: document.getElementById('status-note'),
  statusError: document.getElementById('status-error'),
  facts: document.getElementById('facts'),
  groups: document.getElementById('groups'),
  groupsBody: document.getElementById('groups-body'),
  groupsEmpty: document.getElementById('groups-empty'),
  log: document.getElementById('log'),
  logEmpty: document.getElementById('log-empty'),
  // 表情包管理（see the "表情包管理" section near the bottom of this file).
  stickerSummary: document.getElementById('sticker-summary'),
  stickerStatus: document.getElementById('sticker-status'),
  stickerFilter: document.getElementById('sticker-filter'),
  stickerSelectPage: document.getElementById('sticker-select-page'),
  stickerSelected: document.getElementById('sticker-selected'),
  stickerMoveTarget: document.getElementById('sticker-move-target'),
  stickerMove: document.getElementById('sticker-move'),
  stickerGrid: document.getElementById('sticker-grid'),
  stickerEmpty: document.getElementById('sticker-empty'),
  stickerPage: document.getElementById('sticker-page'),
  stickerPrev: document.getElementById('sticker-prev'),
  stickerNext: document.getElementById('sticker-next'),
  stickerCategories: document.getElementById('sticker-categories'),
  stickerNewName: document.getElementById('sticker-new-name'),
  stickerAdd: document.getElementById('sticker-add'),
};

// --- the bridge --------------------------------------------------------------
//
// The same {v,type,id,method,payload} envelope every plugin uses. A request that
// the host refuses rejects with the host's own Chinese sentence ("插件 X 未获权限
// net.ws"), which is shown verbatim: a generic "操作失败" would hide exactly the
// thing the user has to fix.

const PROTOCOL = 1;
let nextRequestID = 1;
const pending = new Map();

function postToHost(message) {
  if (!window.parent) return;
  window.parent.postMessage({ v: PROTOCOL, ...message }, '*');
}

function request(method, payload) {
  const id = String(nextRequestID++);
  postToHost({ type: 'request', id, method, payload: payload === undefined ? {} : payload });
  return new Promise((resolve, reject) => pending.set(id, { resolve, reject }));
}

/**
 * The same request, but with a deadline.
 *
 * It exists for ONE caller: the protocol-side probe on startup, which must not inherit
 * the host's 30 s `net.fetch` timeout. A bot that waits half a minute to discover that
 * nothing is listening cannot decide whether to start the client in time to be useful.
 *
 * The pending entry is DELETED when the deadline fires, so a response that arrives
 * afterwards is dropped by onResponse instead of resolving a promise nobody awaits -
 * the same rule the host's own refusals follow: a timed-out call does nothing.
 */
function requestWithTimeout(method, payload, timeoutMs) {
  const id = String(nextRequestID++);
  postToHost({ type: 'request', id, method, payload: payload === undefined ? {} : payload });
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      pending.delete(id);
      reject(new Error(`请求超时（${timeoutMs} ms）`));
    }, timeoutMs);
    pending.set(id, {
      resolve: (value) => {
        clearTimeout(timer);
        resolve(value);
      },
      reject: (err) => {
        clearTimeout(timer);
        reject(err);
      },
    });
  });
}

/** Resolves after ms; used to let a just-started program come up. */
function sleep(ms) {
  return new Promise((resolve) => {
    setTimeout(resolve, ms);
  });
}

/** Everything the host granted, upper-cased membership is unnecessary: ids are exact. */
const granted = new Set();
let self = { pluginId: '', surface: {} };
let view = 'workshop';

// --- plugin state ------------------------------------------------------------

/** The settings declared in manifest.json, as strings, with these fallbacks. */
const DEFAULTS = {
  server: '127.0.0.1:3000',
  accessToken: '',
  atOnly: 'true',
  replyChance: '0',
  proactiveMinutes: '0',
  prefix: '',
  groupAllow: '',
  persona: '',
  contextTurns: '8',
  replyMaxChars: '300',
  cooldownSec: '5',
  quoteReply: 'true',
  llmProvider: '',
  llmBaseUrl: '',
  llmModel: '',
  // The protocol side (Yogurt) itself: where its exe lives, what to pass it, and
  // whether this plugin may start it. Empty + off by default - starting a program is
  // the user's decision, never the default.
  clientPath: '',
  clientArgs: '',
  autoStartClient: 'false',
  // B 站联动：群里出现链接时发视频、刷到值得看的时在群里 @ 主人。
  //
  // The caps and the switch live HERE rather than in the Bilibili plugin because this is
  // the side that owns a group: how much a group will tolerate is not a property of the
  // video, and the plugin that decides "send to whom" should own "how big".
  biliLinkReply: 'false',
  biliLinkAtOwner: 'true',
  biliMaxMB: '80',
  biliMaxMinutes: '25',
  biliRecommendGroup: '',
  // Absolute path of ffmpeg.exe. Empty means "no video": a video that cannot be muxed is
  // sent as a link instead, never as a broken message.
  ffmpegPath: '',
};

const state = {
  cfg: { ...DEFAULTS },
  base: '',
  eventUrl: '',
  ws: 'closed',
  wsError: '',
  selfID: '',
  selfName: '',
  counts: { frames: 0, asked: 0, replies: 0, errors: 0 },
  /** peer_id -> { id, name, count, lastAt } - the memory index the workshop reads. */
  groups: new Map(),
  /** peer_id -> epoch ms of the last answer, for the cooldown. */
  lastAnswer: new Map(),
  /** peer_id -> epoch ms of the last "I stayed silent" log line, so it is rate-limited. */
  ignoredAt: new Map(),
  /** peer_id -> epoch ms of the last sticker, for the per-group cooldown. */
  lastStickerAt: new Map(),
  /** peer_id set: one answer in flight per group. */
  busy: new Set(),
  log: [],
  started: false,
  // --- B 站联动 -------------------------------------------------------------
  /** link -> epoch ms it was requested, so one link is not requested twice. */
  biliLinks: new Map(),
  /** job id -> { groupID, senderID, at }: a result carries no group, and it must not. */
  biliPending: new Map(),
  /** Result / recommendation ids already announced. */
  biliSeenResults: [],
  biliSeenRecommends: [],
  /** groupID -> epoch ms of the last "cannot send, here is the link" note. */
  biliNoticeAt: new Map(),
  /** True while the bridge is mid-flight, so two 5 s ticks cannot double-send. */
  bridgeBusy: false,
  bridgeStartedAt: 0,
  bridgeTimer: null,
};

const LOG_KEY = 'log';
const GROUPS_KEY = 'groups';
const STATUS_KEY = 'status';
const HISTORY_PREFIX = 'hist_';
const maxLogEntries = 60;

// --- small helpers -----------------------------------------------------------

function flag(value, fallback) {
  if (value === undefined || value === null || value === '') return fallback;
  return String(value).toLowerCase() === 'true';
}

function number(value, fallback, min, max) {
  const n = Number.parseInt(String(value ?? ''), 10);
  if (!Number.isFinite(n)) return fallback;
  return Math.min(max, Math.max(min, n));
}

/** Splits a "list typed into one field" setting; accepts both comma kinds. */
function listOf(value) {
  return String(value || '')
    .split(/[,，;；\s]+/)
    .map((item) => item.trim())
    .filter(Boolean);
}

/**
 * Splits the `clientArgs` setting into an argument list.
 *
 * Whitespace only, unlike listOf: a comma or a Chinese comma can legitimately appear
 * INSIDE one argument (a path, a token), so splitting on it would silently break the
 * invocation. The host caps the list at 32 arguments and refuses the call rather than
 * dropping the extras, so an over-long list is reported instead of half-applied.
 */
function argsOf(value) {
  return String(value || '')
    .split(/\s+/)
    .map((item) => item.trim())
    .filter(Boolean);
}

function trimTo(text, max) {
  const runes = Array.from(String(text || ''));
  if (runes.length <= max) return runes.join('');
  return runes.slice(0, max).join('');
}

/**
 * Derives the two endpoints from ONE setting.
 *
 * `server` may be `host:port`, `http://host:port/prefix` or `ws://host:port/prefix`.
 * Milky's own config has a `prefix` field, and a deployment that sets it must be
 * reachable; asking for two URLs would make it possible to change one and not the
 * other, and the failure ("events arrive, answers do not") is hard to read.
 */
function endpointsFor(server, token) {
  const raw = String(server || '').trim() || DEFAULTS.server;
  let scheme = 'http';
  let host = raw;
  let path = '';
  const withScheme = /^([a-z]+):\/\/(.*)$/i.exec(raw);
  if (withScheme) {
    const given = withScheme[1].toLowerCase();
    const rest = withScheme[2];
    scheme = given === 'https' || given === 'wss' ? 'https' : 'http';
    const slash = rest.indexOf('/');
    host = slash >= 0 ? rest.slice(0, slash) : rest;
    path = slash >= 0 ? rest.slice(slash).replace(/\/+$/, '') : '';
  }
  const secure = scheme === 'https';
  const base = `${secure ? 'https' : 'http'}://${host}${path}`;
  const wsScheme = secure ? 'wss' : 'ws';
  // A token may only travel as a query parameter on a WebSocket: the browser API
  // has no headers, and the host's dialer sends `Authorization` as well - Milky
  // accepts either, and sending both is what the SDK does.
  const query = token ? `?access_token=${encodeURIComponent(token)}` : '';
  return { base, eventUrl: `${wsScheme}://${host}${path}/event${query}` };
}

// --- logging / persistence ---------------------------------------------------

function note(line) {
  const stamp = new Date().toLocaleTimeString('zh-CN', { hour12: false });
  state.log.push(`${stamp} ${line}`);
  if (state.log.length > maxLogEntries) state.log.splice(0, state.log.length - maxLogEntries);
  if (view === 'workshop') renderLog();
  schedulePersist();
}

/**
 * Writes the three cross-process files, coalescing while a write is in flight.
 *
 * The workshop runs in the MARKET's process, so the only way it can show what the
 * bot is doing is through the plugin's own storage. Writes are driven by the events
 * worth showing - a state change, an answer, a refusal - and never by inbound frames
 * as such, so the cost is a handful of small files per answered message rather than
 * a write per group message.
 *
 * There is no debounce timer on purpose: a timer means the interesting entry (a
 * permission refusal, a dropped connection) can be the one still sitting in the
 * buffer, and "the dashboard was blank for a second" is indistinguishable from "it
 * did not react". An in-flight flag does the coalescing instead, so a burst of notes
 * costs one write plus one follow-up.
 */
let persisting = false;
let persistDirty = false;

function schedulePersist() {
  if (view !== 'background') return;
  if (!granted.has('storage')) return;
  if (persisting) {
    persistDirty = true;
    return;
  }
  void persistNow();
}

async function persistNow() {
  persisting = true;
  persistDirty = false;
  try {
    await request('storage.set', {
      key: STATUS_KEY,
      value: JSON.stringify({
        state: state.ws,
        error: state.wsError,
        selfID: state.selfID,
        selfName: state.selfName,
        at: Date.now(),
        counts: state.counts,
      }),
    });
    await request('storage.set', {
      key: GROUPS_KEY,
      value: JSON.stringify([...state.groups.values()]),
    });
    await request('storage.set', { key: LOG_KEY, value: JSON.stringify(state.log) });
  } catch (err) {
    // A storage failure is worth one line, not a loop: the bot keeps answering.
    console.warn('qq plugin: could not persist', err && err.message);
  } finally {
    persisting = false;
    if (persistDirty) {
      persistDirty = false;
      void persistNow();
    }
  }
}

// --- Milky API ---------------------------------------------------------------

/**
 * Calls one Milky API endpoint.
 *
 * Milky's transport is `POST {base}/api/{name}` with a JSON body and an optional
 * `Authorization: Bearer` header, and the reply is `{status, retcode, message, data}`
 * - a 200 with `status: "failed"` is a real failure, which is why both are checked.
 */
async function api(name, params) {
  const headers = { accept: 'application/json', 'content-type': 'application/json' };
  if (state.cfg.accessToken) headers.authorization = `Bearer ${state.cfg.accessToken}`;
  const res = await request('net.fetch', {
    method: 'POST',
    url: `${state.base}/api/${name}`,
    body: JSON.stringify(params || {}),
    headers,
  });
  let payload = null;
  try {
    payload = JSON.parse(String(res && res.body ? res.body : ''));
  } catch {
    payload = null;
  }
  if (payload && payload.status === 'failed') {
    throw new Error(payload.message || `${name} 失败（retcode ${payload.retcode}）`);
  }
  if (!res || res.status >= 400) {
    throw new Error(`${name} 返回 HTTP ${res ? res.status : '?'}`);
  }
  return payload ? payload.data : null;
}

// --- message handling --------------------------------------------------------

/** True when this group's id is allowed by the `groupAllow` setting. */
function groupAllowed(groupID) {
  const allow = listOf(state.cfg.groupAllow);
  if (allow.length === 0) return true;
  return allow.includes(String(groupID));
}

/** True when the segments mention the bot itself (an `@`). */
function mentionsBot(segments, selfID) {
  if (!selfID) return false;
  for (const seg of segments) {
    if (!seg || seg.type !== 'mention' || !seg.data) continue;
    if (String(seg.data.user_id) === String(selfID)) return true;
  }
  return false;
}

/**
 * Flattens the segments into the text the model reads.
 *
 * Non-text segments become bracketed placeholders rather than being dropped: a
 * message that is only an image would otherwise arrive as an empty string and be
 * answered as if nothing had been said.
 *
 * `image` carries a `summary` (the platform's own description, e.g. "[动画表情]"), so
 * that is used when present - "[图片]" alone tells a model nothing it can act on.
 * Reading the PICTURE itself needs a multimodal request, which the host's llm.chat
 * does not send (it sends text messages only); the url is deliberately NOT written
 * into the prompt, because a model that cannot see it would hallucinate about it.
 */
function plainText(segments, selfID) {
  const parts = [];
  for (const seg of segments) {
    if (!seg) continue;
    const data = seg.data || {};
    switch (seg.type) {
      case 'text':
        parts.push(String(data.text || ''));
        break;
      case 'mention':
        if (String(data.user_id) !== String(selfID)) {
          parts.push(`@${data.name || data.user_id}`);
        }
        break;
      case 'mention_all':
        parts.push('@全体成员');
        break;
      case 'face':
        parts.push('[表情]');
        break;
      case 'image': {
        const summary = String(data.summary || '').trim();
        parts.push(summary ? `[图片：${summary}]` : '[图片]');
        break;
      }
      case 'record':
        parts.push('[语音]');
        break;
      case 'video':
        parts.push('[视频]');
        break;
      case 'file':
        parts.push(`[文件：${String(data.file_name || '').trim() || '未命名'}]`);
        break;
      case 'forward':
        // Replaced by the expanded text when the API answers; see enrichSegments.
        parts.push(forwardPlaceholder(data));
        break;
      case 'market_face':
        parts.push('[表情]');
        break;
      case 'json':
      case 'xml':
      case 'light_app': {
        // A shared card (B 站, 公众号, 音乐…) used to vanish completely: the type was not
        // in this switch, so the model saw a message with nothing in it and had no way to
        // react to what was shared. The title is the part worth keeping.
        const title = cardTitle(seg.data);
        parts.push(title ? `[卡片：${title}]` : '[卡片]');
        break;
      }
      case 'reply':
        // The quoted message's own segments travel with the reply segment, but the
        // quote is rendered as a PREFIX by enrichSegments, so it is skipped here.
        break;
      default:
        break;
    }
  }
  return parts.join('').replace(/\s+/g, ' ').trim();
}

/**
 * The title of a shared card, wherever that card keeps it.
 *
 * Cards arrive as `{data: "<json string>"}`, as `{json_payload: "..."}`, as an already
 * nested object, or as XML - and QQ's structmsg puts the title under `meta.news.title`
 * or `meta.detail_1.title/desc`. Four shapes, one answer, bounded so a hostile payload
 * cannot turn into a paragraph.
 */
function cardTitle(data) {
  const payload = data || {};
  const raw = [payload.data, payload.json_payload, payload.xml, payload.content].find((value) => typeof value === 'string' && value.trim());
  const text = String(raw || '');
  if (text) {
    const xmlTitle = /<title>([\s\S]{1,80}?)<\/title>/.exec(text);
    if (xmlTitle) return xmlTitle[1].trim();
    try {
      const parsed = JSON.parse(text);
      const title = pickCardTitle(parsed);
      if (title) return title;
    } catch {
      // Not JSON (or not parseable): fall through to the regex below.
    }
    const loose = /"(?:title|desc)"\s*:\s*"([^"]{1,80})"/.exec(text);
    if (loose) return loose[1];
  }
  return pickCardTitle(payload);
}

function pickCardTitle(value) {
  if (!value || typeof value !== 'object') return '';
  const meta = value.meta || {};
  const candidates = [
    meta.news && meta.news.title,
    meta.detail_1 && meta.detail_1.title,
    meta.detail_1 && meta.detail_1.desc,
    meta.music && meta.music.title,
    value.prompt,
    value.title,
  ];
  for (const candidate of candidates) {
    const text = String(candidate || '').trim();
    if (text) return text.slice(0, 80);
  }
  return '';
}

/** What a forward block looks like when its content could not be fetched. */
function forwardPlaceholder(data) {
  const title = String(data.title || '').trim();
  const summary = String(data.summary || '').trim();
  const preview = Array.isArray(data.preview) ? data.preview.slice(0, 3) : [];
  const bits = [title, summary].filter(Boolean);
  let text = `[合并转发${bits.length ? '：' + bits.join(' / ') : ''}]`;
  if (preview.length) {
    text += `\n预览：${preview.map((p) => String(p).trim()).filter(Boolean).join(' | ')}`;
  }
  return text;
}

/**
 * Turns the inbound segments into the text the model reads, WITH the two things that
 * need a second look: the quoted message, and the inside of a forwarded block.
 *
 * Both were silently dropped before, which made two ordinary situations unanswerable:
 * "reply to the bot with a quote and ask about it" arrived as a bare question with no
 * subject, and a forwarded chat log arrived as "[合并转发]" and nothing else.
 *
 *   - QUOTE: Milky's `reply` segment carries the quoted message's own `segments`,
 *     `sender_name` and `time`, so no extra request is needed - the text is already
 *     in the event.
 *   - FORWARD: only an id is carried, so the content has to be fetched with
 *     `get_forwarded_messages`. Failure is tolerated rather than fatal: the block
 *     still shows its title/summary/preview, which is what the user sees in QQ too.
 */
async function enrichSegments(segments, selfID, groupID) {
  const quoted = [];
  const forwarded = [];
  /** Segments of the quoted message(s), so their pictures can be collected too. */
  const quoteSegments = [];
  for (const seg of segments || []) {
    if (!seg) continue;
    if (seg.type === 'reply' && seg.data) {
      let inner = Array.isArray(seg.data.segments) ? seg.data.segments : [];
      // The protocol side may send the quote as an "empty" reference (only
      // message_seq/sender/time). Then the quoted content - text AND pictures - has to
      // be fetched by sequence number, which is what made "引用一张图再问这是什么"
      // arrive as a question about nothing.
      if (!inner.length && seg.data.message_seq) {
        inner = await fetchQuotedSegments(groupID, seg.data.message_seq);
      }
      for (const item of inner) quoteSegments.push(item);
      const text = plainText(inner, selfID).trim();
      const who = String(seg.data.sender_name || seg.data.sender_id || '').trim();
      if (text) {
        quoted.push(`（引用${who ? ' ' + who : ''}：${clampOneLine(text, 300)}）`);
      } else if (inner.length) {
        quoted.push(`（引用${who ? ' ' + who : ''}：一条非文字消息）`);
      }
    } else if (seg.type === 'forward' && seg.data && seg.data.forward_id) {
      forwarded.push(seg.data);
    }
  }

  let body = plainText(segments, selfID);
  if (forwarded.length) {
    const expanded = [];
    for (const block of forwarded.slice(0, 2)) {
      expanded.push(await expandForward(block, groupID));
    }
    // The placeholder is already the fallback text, so replacing the whole body is
    // wrong when other segments were present: the expansion is appended instead.
    body = `${body}\n${expanded.join('\n')}`.trim();
  }
  if (quoted.length) {
    body = `${quoted.join('\n')}\n${body}`.trim();
  }
  return { text: body, quoteSegments };
}

/**
 * Fetches the segments of the message a `reply` segment points at.
 *
 * Milky's `get_message` takes the scene, the peer and the sequence; the reply shape
 * varies between implementations (an array, or `{message:{segments}}`, or
 * `{segments}`), so all three are accepted. Failure is logged and treated as "no
 * quoted content" - a quote that cannot be read is not worth failing the answer for.
 */
async function fetchQuotedSegments(groupID, messageSeq) {
  try {
    const res = await api('get_message', {
      message_scene: 'group',
      peer_id: Number(groupID) || groupID,
      message_seq: Number(messageSeq),
    });
    const payload = res && res.message !== undefined ? res.message : res;
    if (Array.isArray(payload)) return payload;
    if (payload && Array.isArray(payload.segments)) return payload.segments;
    return [];
  } catch (err) {
    note(`引用内容取不到（协议端只能读到启动之后的消息），按无引用处理：${(err && err.message) || err}`);
    return [];
  }
}

/**
 * Fetches one forwarded block's messages and renders them as plain text.
 *
 * The cap (8 messages, 80 characters each) is a budget decision: a forwarded log can
 * be hundreds of messages, and sending all of it would cost more than the answer is
 * worth while pushing the actual question out of the model's attention.
 */
async function expandForward(block, groupID) {
  try {
    const res = await api('get_forwarded_messages', {
      forward_id: String(block.forward_id),
      peer_id: Number(groupID) || groupID,
      message_scene: 'group',
    });
    const rows = Array.isArray(res) ? res : (res && Array.isArray(res.messages) ? res.messages : []);
    if (!rows.length) return forwardPlaceholder(block);
    const lines = rows.slice(0, 8).map((row) => {
      const who = String(row.sender_name || row.user_id || '').trim();
      const text = plainText(Array.isArray(row.segments) ? row.segments : [], '').trim();
      return `${who ? who + '：' : ''}${trimTo(text, 80)}`;
    }).filter((line) => line.trim() !== '');
    if (!lines.length) return forwardPlaceholder(block);
    const more = rows.length > lines.length ? `\n（还有 ${rows.length - lines.length} 条）` : '';
    return `[合并转发内容]\n${lines.join('\n')}${more}`;
  } catch (err) {
    note(`读取转发消息失败：${(err && err.message) || err}`);
    return forwardPlaceholder(block);
  }
}

/** Clamps a multi-line string to n characters, keeping it single-line. */
function clampOneLine(text, n) {
  return trimTo(String(text || '').replace(/\s+/g, ' ').trim(), n);
}

/** Strips the configured trigger prefix, when the message starts with it. */
function stripPrefix(text) {
  const prefix = String(state.cfg.prefix || '').trim();
  if (!prefix) return text;
  if (!text.startsWith(prefix)) return text;
  return text.slice(prefix.length).trim();
}

/**
 * Whether this message is addressed to the bot - or worth an unprompted reply.
 *
 * THREE tiers, and the middle one is the reason this is not a boolean:
 *
 *   1. a mention, or a configured prefix, ALWAYS answers. That is the user talking
 *      to the bot on purpose;
 *   2. `atOnly` (the default) refuses everything else. It is the only mode that
 *      cannot flood a group, and it stays the default;
 *   3. with `atOnly` off, `replyChance` decides how often it joins in: 0 never,
 *      100 every message, anything between is a coin flip per message.
 *
 * Why a percentage rather than "on/off": "reply to everything" is a different
 * feature from "occasionally chime in", and the useful setting is the second one.
 * A switch would force the user to choose between silence and a monologue, and the
 * cooldown (5s by default) would turn the monologue into "answers once every five
 * seconds" - which reads as a broken bot rather than a chatty one.
 */
function shouldAnswer(text, mentioned) {
  if (mentioned) return true;
  const prefix = String(state.cfg.prefix || '').trim();
  if (prefix !== '' && text.startsWith(prefix)) return true;
  if (flag(state.cfg.atOnly, true)) return false;
  const chance = number(state.cfg.replyChance, 0, 0, 100);
  if (chance <= 0) return false;
  if (chance >= 100) return true;
  return Math.random() * 100 < chance;
}

/** The speaker's display name, preferring the group card over the nickname. */
function speakerOf(data) {
  const member = data.group_member || {};
  const card = String(member.card || '').trim();
  if (card) return card;
  const nickname = String(member.nickname || '').trim();
  if (nickname) return nickname;
  return String(data.sender_id || '某人');
}

/**
 * The picture URLs worth sending to a vision model.
 *
 * Empty unless `visionModel` is set, which is the switch: without it the pictures stay
 * as `[图片：摘要]` text and cost nothing. The count is capped by `visionMaxImages`
 * because every picture is billed as tokens on every turn it appears in.
 */
function imagesOf(segments) {
  const model = String(state.cfg.visionModel || '').trim();
  const max = number(state.cfg.visionMaxImages, 2, 0, 4);
  if (!model || max <= 0) return [];
  const urls = [];
  const seen = new Set();
  const add = (seg) => {
    if (!seg || seg.type !== 'image' || !seg.data || !seg.data.temp_url) return;
    const url = String(seg.data.temp_url);
    if (seen.has(url)) return;
    seen.add(url);
    urls.push(url);
  };
  for (const seg of segments || []) {
    // A picture the user REPLIED to lives inside the reply segment, not at the top
    // level - and "引用一张图再问这是什么" is the commonest way people ask about an
    // image. Scanning only the top level made that arrive with no picture at all,
    // and the model answered "我没看到图" - which was literally true.
    if (seg && seg.type === 'reply' && seg.data) {
      for (const inner of seg.data.segments || []) add(inner);
    }
    add(seg);
  }
  return urls.slice(0, max);
}

/**
 * Asks the model, with pictures when there are any and the vision model is configured.
 *
 * The fallback is deliberate and narrow: if the vision request is REFUSED with an
 * error that names 图片 (the host's allow-list, or a gateway that does not take image
 * parts), the same question is retried as text. A group question should not go
 * unanswered because one picture could not be looked at - and the log says which
 * happened.
 */
async function askModel(text, system, history, images) {
  const model = String(state.cfg.visionModel || '').trim();
  const payload = { text, system, history };
  let withImages = false;
  if (images && images.length && model) {
    payload.model = model;
    payload.images = images;
    const extra = String(state.cfg.visionPrompt || '').trim();
    if (extra) payload.system = `${system}\n\n${extra}`;
    withImages = true;
  }
  try {
    return await request('llm.chat', payload);
  } catch (err) {
    const message = String((err && err.message) || err);
    if (withImages && message.includes('图片')) {
      note(`看图没成功，改用文字回答：${message}`);
      return await request('llm.chat', { text, system, history });
    }
    throw err;
  }
}

// --- 素材导入：私聊合并转发 → 识图分类 → 入库 ------------------------------

/**
 * A tiny FNV-1a hash, used as the sticker's identity.
 *
 * Not a cryptographic hash and deliberately so: the job is "have I seen these exact
 * bytes before", over data the owner just sent to their own bot. It runs in the page
 * with no imports, which is why the plugin needs no new capability for it.
 */
function hashOf(text) {
  let h = 0x811c9dc5;
  for (let i = 0; i < text.length; i += 1) {
    h ^= text.charCodeAt(i);
    h = (h * 0x01000193) >>> 0;
  }
  return h.toString(16).padStart(8, '0');
}

/** True for a private message from the configured owner. */
function isOwner(event, data) {
  const owner = String(state.cfg.ownerQQ || '').trim();
  if (!owner) return false;
  const sender = String((data && data.sender_id) || '');
  // The protocol side reports the bot's own messages too; without this guard the
  // import would classify its own summary replies.
  const selfID = String(event.self_id || state.selfID || '');
  if (selfID && sender === selfID) return false;
  return sender === owner;
}

/** Sends one private reply to the owner (progress and results). */
async function replyToOwner(userID, text) {
  try {
    await api('send_private_message', {
      user_id: Number(userID),
      message: [{ type: 'text', data: { text } }],
    });
  } catch (err) {
    note(`私聊回复失败：${(err && err.message) || err}`);
  }
}

/** Every image URL in one list of segments (top level, quoted, or forwarded). */
async function imageUrlsIn(segments, groupID) {
  const urls = [];
  const seen = new Set();
  const add = (seg) => {
    if (!seg || seg.type !== 'image' || !seg.data || !seg.data.temp_url) return;
    const url = String(seg.data.temp_url);
    if (seen.has(url)) return;
    seen.add(url);
    urls.push(url);
  };
  for (const seg of segments || []) {
    if (!seg) continue;
    if (seg.type === 'image') add(seg);
    else if (seg.type === 'reply' && seg.data) {
      for (const inner of seg.data.segments || []) add(inner);
    } else if (seg.type === 'forward' && seg.data && seg.data.forward_id) {
      try {
        const res = await api('get_forwarded_messages', {
          forward_id: String(seg.data.forward_id),
          peer_id: Number(groupID) || groupID,
          message_scene: 'private',
        });
        const rows = Array.isArray(res) ? res : (res && Array.isArray(res.messages) ? res.messages : []);
        for (const row of rows) {
          for (const inner of (row && row.segments) || []) add(inner);
        }
      } catch (err) {
        note(`展开转发失败：${(err && err.message) || err}`);
      }
    }
  }
  return urls;
}

/**
 * Asks the vision model what ONE sticker is: a category from the closed set, plus a
 * short description. The answer is parsed defensively - a model that adds prose still
 * yields a usable category, and an unusable answer is skipped rather than guessed at.
 */
async function classifySticker(url) {
  const res = await request('llm.chat', {
    text: '这是 QQ 聊天里的一张表情包。只回答两行：第一行是分类（只能选一个：' +
      STICKER_TAGS.join('/') + '），第二行是十个字以内的画面描述。',
    system: '你是一个给表情包打标签的助手，只输出分类和描述，不要解释。',
    model: String(state.cfg.visionModel || '').trim(),
    images: [url],
  });
  const lines = String((res && res.text) || '')
    .split(/[\r\n]+/)
    .map((line) => line.trim())
    .filter(Boolean);
  const tag = STICKER_TAGS.find((candidate) => (lines[0] || '').includes(candidate)) || '';
  const description = clampOneLine(lines[1] || lines[0] || '', 40);
  return { tag, description };
}

/** Loads the sticker index (`[{hash, tag, description}]`). */
async function loadStickerIndex() {
  try {
    const res = await request('storage.get', { key: 'stickers' });
    const parsed = JSON.parse((res && res.value) || '[]');
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

/**
 * Imports every sticker in one message: fetch the bytes, classify them, store them.
 *
 * Base64 in the plugin's private storage rather than the CDN url, because those urls
 * expire: a library of expiring links is a library that goes empty overnight. The
 * bytes also make the identity (hash) stable, so sending the same pack twice adds
 * nothing.
 */
async function importStickers(event, data) {
  const userID = String(data.sender_id || '');
  const segments = Array.isArray(data.segments) ? data.segments : [];
  const urls = await imageUrlsIn(segments, data.peer_id);
  if (!urls.length) {
    await replyToOwner(userID, '没在这条消息里找到图片。发一条「合并转发」或者直接发图给我。');
    return;
  }
  const model = String(state.cfg.visionModel || '').trim();
  if (!model) {
    await replyToOwner(userID, '还没设置看图模型（visionModel），没法识别图片。');
    return;
  }
  const index = await loadStickerIndex();
  const known = new Set(index.map((row) => row.hash));
  const tally = new Map();
  let added = 0;
  let failed = 0;
  await replyToOwner(userID, `收到 ${urls.length} 张图，正在识别…`);
  for (const url of urls) {
    try {
      const fetched = await request('net.fetch', { url, encoding: 'base64' });
      const base64 = String((fetched && fetched.body) || '');
      if (!base64) {
        failed += 1;
        continue;
      }
      const hash = hashOf(base64);
      if (known.has(hash)) continue;
      const { tag, description } = await classifySticker(url);
      if (!tag) {
        failed += 1;
        continue;
      }
      await request('storage.set', { key: `sticker_${hash}`, value: base64 });
      index.push({ hash, tag, description });
      known.add(hash);
      tally.set(tag, (tally.get(tag) || 0) + 1);
      added += 1;
    } catch (err) {
      failed += 1;
      note(`识别失败：${(err && err.message) || err}`);
    }
  }
  await request('storage.set', { key: 'stickers', value: JSON.stringify(index) });
  const summary = [...tally.entries()].map(([tag, n]) => `${tag} ${n}`).join('、') || '无新增';
  await replyToOwner(
    userID,
    `入库完成：新增 ${added} 张，跳过 ${urls.length - added - failed} 张（已存在），失败 ${failed} 张。分类：${summary}`,
  );
  note(`素材导入：新增 ${added} 张，失败 ${failed} 张`);
}

/** One inbound private message: the owner's import channel, and nothing else. */
async function onPrivateMessage(event) {
  const data = event.data || {};
  if (!isOwner(event, data)) return;
  const segments = Array.isArray(data.segments) ? data.segments : [];
  const hasImage = segments.some((seg) => seg && (seg.type === 'image' || seg.type === 'forward'));
  if (!hasImage) {
    await replyToOwner(String(data.sender_id || ''), '把表情包用「合并转发」发我，或者直接发图片。');
    return;
  }
  await importStickers(event, data);
}

// --- 表情包 ----------------------------------------------------------------

/** The moods the model may ask for. A closed set, so a stray word is not a sticker. */
const STICKER_TAGS = ['开心', '无语', '疑惑', '惊讶', '点赞', '嘲笑', '委屈', '生气', '沉默', '摸鱼'];

/** The instruction appended to every system prompt, so the protocol is one string. */
const STICKER_INSTRUCTION =
  `- 每条回复都必须在最后加上〔表情:分类〕，分类只能是：${STICKER_TAGS.join('/')}；` +
  '这个标记只给程序读，必须加、不能省略，也不要解释它。';

/**
 * Splits the model's reply into text and an optional mood tag.
 *
 * A tag protocol rather than a JSON envelope: the reply is sent to a group as-is, and
 * asking for JSON would either need a second call or leak braces into the message when a
 * model forgets. A trailing marker is stripped harmlessly when it is absent.
 */
function splitStickerTag(text) {
  const raw = String(text || '');
  const match = raw.match(/[〔\[（(]\s*表情\s*[:：]\s*([^〕\]）)]+?)\s*[〕\]）)]\s*$/);
  if (!match) return { text: raw.trim(), tag: '' };
  const tag = match[1].trim();
  const cleaned = raw.slice(0, match.index).trim();
  return { text: cleaned, tag: STICKER_TAGS.includes(tag) ? tag : '' };
}

/** The sticker library: one http(s) URL per line. Empty means the feature is off. */
function stickerLibrary() {
  const out = [];
  for (const line of String(state.cfg.stickerUrls || '').split(/[\r\n]+/)) {
    const trimmed = line.trim();
    if (!trimmed || !/^https?:\/\//i.test(trimmed)) continue;
    out.push(trimmed);
  }
  return out;
}

/**
 * Sends one sticker after a reply, when the settings and the moment allow it.
 *
 * Three gates, all cheap and all necessary: a probability (a bot that stickers every
 * message gets muted), a per-group cooldown, and a non-empty tag. Failures are logged and
 * forgotten - a reply that went out without a sticker is not an error.
 */
async function maybeSendSticker(groupID, tag) {
  if (!tag) return;
  const library = stickerLibrary();
  // An empty URL list no longer disables the feature: the imported library is the
  // primary source now, and the URL list is only the fallback.
  const chance = number(state.cfg.stickerChance, 30, 0, 100);
  // Every gate below names itself in the log. These three returns used to be silent,
  // which made the one report that matters - "it answered but never sends a sticker" -
  // impossible to diagnose: the group saw a reply, the log saw nothing, and "probability",
  // "cooldown" and "nothing in that category" were indistinguishable from each other.
  if (chance <= 0) {
    note(`这次不发表情：配表情的概率是 0（群 ${groupID}）`);
    return;
  }
  if (chance < 100 && Math.random() * 100 >= chance) {
    note(`这次不发表情：概率没中（群 ${groupID}，配表情概率 ${chance}%）`);
    return;
  }
  const now = Date.now();
  const gap = number(state.cfg.stickerCooldownSec, 120, 0, 86400) * 1000;
  const lastAt = state.lastStickerAt.get(groupID) || 0;
  if (now - lastAt < gap) {
    const left = Math.max(1, Math.ceil((gap - (now - lastAt)) / 1000));
    note(`这次不发表情：还在冷却里，还要等 ${left} 秒（群 ${groupID}）`);
    return;
  }
  state.lastStickerAt.set(groupID, now);
  const picked = await pickStickerForTag(tag, library);
  if (!picked) {
    note(`这次不发表情：图库里没有「${tag}」分类的表情（群 ${groupID}）`);
    return;
  }
  try {
    await api('send_group_message', {
      group_id: Number(groupID),
      message: [{ type: 'image', data: { uri: picked.uri, sub_type: 'sticker', summary: `[表情：${tag}]` } }],
    });
    state.counts.replies += 1;
    note(`在群 ${groupID} 发了一张表情（${tag}，来源:${picked.kind}）`);
  } catch (err) {
    note(`表情发送失败：${(err && err.message) || err}`);
  }
}

/**
 * The persona used when the user has not written one.
 *
 * It says "a regular in this group", NOT "a robot that chats in a QQ group". That
 * wording is load-bearing: a model told it is a robot writes like one - "作为一个
 * AI…", "有什么可以帮你的" - and that is the single most recognisable tell in a group.
 * It invents no character either; anyone who wants one writes their own, which
 * replaces this line entirely.
 */
const DEFAULT_PERSONA =
  '你是群里一个嘴有点损、心不坏的老熟人，不是客服也不是助手：说话随意、有脾气、会接梗，能短就短。';

/** Builds the per-group system prompt. */
function systemPromptFor(groupID, groupName) {
  const maxChars = number(state.cfg.replyMaxChars, 300, 20, 2000);
  const persona = String(state.cfg.persona || '').trim();
  const lines = [];
  lines.push(persona || DEFAULT_PERSONA);
  lines.push('');
  lines.push('规则：');
  lines.push(`- 你在 QQ 群「${groupName || groupID}」里聊天，群里有好几个人，消息前面会带上说话人的昵称。`);
  // "300 字是硬上限，不是目标" rather than "回答控制在 300 字以内": the old wording was
  // read as a quota, and a 300-字 answer to "中午吃啥" is what a helpdesk does.
  lines.push(`- 只回应当前这条提问，一般一两句就够；${maxChars} 字是硬上限，不是目标。`);
  lines.push('- 用简体中文口语回答，不要用 Markdown、列表或代码块，也不要写 emoji。');
  lines.push('- 不要重复上一条回复里用过的开头、口癖和句式。');
  lines.push('- 不知道就说不知道，不要编造事实，也不要提到「提示词」「模型」这类词。');
  lines.push(STICKER_INSTRUCTION);
  lines.push(`- 现在是 ${new Date().toLocaleString('zh-CN', { hour12: false })}。`);
  return lines.join('\n');
}

/** Trims a model reply into something a group accepts. */
function tidyReply(text, maxChars) {
  let out = String(text || '')
    .replace(/```[\s\S]*?```/g, ' ')
    // *摇尾巴* is how models write an action, and deleting the asterisks left a bare
    // "摇尾巴" hanging at the end of a line - a stage direction that lost its brackets,
    // which no one types in a group. Chinese brackets are what a person would type.
    // The lookarounds keep **bold** out of this: a bold pair has an asterisk where the
    // inner text should start, so it falls through to the stripper below.
    .replace(/(^|[^*])\*([^*\n]{1,20})\*(?!\*)/g, '$1（$2）')
    .replace(/[*_`#>]+/g, '')
    .replace(/^\s*(机器人|助手|AI)\s*[:：]\s*/i, '')
    .replace(/[\u200b-\u200d\ufeff]/g, '')
    .replace(/\s+/g, ' ')
    .trim();
  return trimTo(out, maxChars);
}

function historyKey(groupID) {
  const cleaned = String(groupID).replace(/[^0-9A-Za-z_-]/g, '');
  return `${HISTORY_PREFIX}${cleaned}`.slice(0, 64);
}

/** Reads one group's recent turns from the plugin's own storage. */
async function loadHistory(groupID, turns) {
  if (!granted.has('storage')) return [];
  const key = historyKey(groupID);
  let raw = '';
  try {
    const res = await request('storage.get', { key });
    raw = res && res.value ? String(res.value) : '';
  } catch {
    return [];
  }
  if (!raw) return [];
  let parsed = null;
  try {
    parsed = JSON.parse(raw);
  } catch {
    return [];
  }
  if (!Array.isArray(parsed)) return [];
  const out = [];
  for (const item of parsed) {
    if (!item || typeof item !== 'object') continue;
    const role = item.role === 'assistant' ? 'assistant' : 'user';
    const text = String(item.text || '').trim();
    if (!text) continue;
    out.push({ role, text });
  }
  return out.slice(-Math.max(2, turns * 2));
}

/**
 * Records that this group is ALIVE, whether or not the bot answers it.
 *
 * It is separate from `remember` on purpose: the memory is what the model is told,
 * while this index is "which rooms had people talking recently" - the only thing
 * the proactive path needs to avoid talking into an empty room. Counting only the
 * answered messages would make an idle bot conclude that every group is dead and
 * therefore never speak, which is the one outcome the feature must not have.
 */
function touchGroup(groupID, groupName) {
  const entry = state.groups.get(String(groupID)) || {
    id: String(groupID),
    name: groupName || '',
    count: 0,
    lastAt: 0,
  };
  entry.lastAt = Date.now();
  if (groupName) entry.name = groupName;
  state.groups.set(String(groupID), entry);
  schedulePersist();
}

/**
 * Appends this exchange to the group's memory.
 *
 * `askerText` may be null, which is how a proactive line is stored: there was no
 * question, and inventing one ("（主动开口）" as a user turn) would teach the model
 * on the next turn that someone addressed it with that string.
 */
async function remember(groupID, groupName, askerText, replyText, turns) {
  if (!granted.has('storage')) return;
  const kept = await loadHistory(groupID, turns);
  if (askerText) kept.push({ role: 'user', text: askerText });
  kept.push({ role: 'assistant', text: replyText });
  const trimmed = kept.slice(-Math.max(2, turns * 2));
  const key = historyKey(groupID);
  const entry = state.groups.get(String(groupID)) || {
    id: String(groupID),
    name: groupName || '',
    count: 0,
    lastAt: 0,
  };
  entry.count += 1;
  entry.lastAt = Date.now();
  if (groupName) entry.name = groupName;
  state.groups.set(String(groupID), entry);
  try {
    await request('storage.set', { key, value: JSON.stringify(trimmed) });
  } catch (err) {
    note(`记忆保存失败：${err && err.message}`);
  }
  schedulePersist();
}

/** Sends one text message back into the group, optionally quoting the question. */
async function sendGroupReply(groupID, messageSeq, text) {
  const segments = [];
  // `null` means "there is no message to quote" (a proactive line). The check is
  // explicit rather than `Number.isFinite` alone, because Number(null) is 0 and a
  // reply segment pointing at seq 0 is a protocol error rather than "no quote".
  const canQuote = messageSeq !== null && messageSeq !== undefined &&
    Number.isFinite(Number(messageSeq));
  if (flag(state.cfg.quoteReply, true) && canQuote) {
    segments.push({ type: 'reply', data: { message_seq: Number(messageSeq) } });
  }
  segments.push({ type: 'text', data: { text } });
  await api('send_group_message', { group_id: Number(groupID), message: segments });
  state.counts.replies += 1;
}

// --- 主动开口 ----------------------------------------------------------------

/**
 * The proactive ticker: the bot occasionally says something nobody asked for.
 *
 * `proactiveMinutes` is an AVERAGE gap, not a schedule. Once a minute the plugin
 * draws a 1/N chance, so the gaps are irregular and average N minutes - as opposed
 * to the same offset past every hour, which is the difference between "it
 * occasionally joins in" and "it is a cron job with a personality prompt".
 *
 * Two refusals keep it from being obnoxious, and both are cheap:
 *
 *   - it never speaks into a room nobody has used within the last N minutes. That is
 *     the only reason `touchGroup` exists: an idle group has nothing to join, and a
 *     bot that starts a conversation with itself is the trait people remove.
 *   - it shares the per-group single-flight and cooldown with the answering path, so
 *     it cannot talk over itself or land on top of a reply that is still streaming.
 */
let proactiveTimer = 0;

function startProactive() {
  stopProactive();
  const minutes = number(state.cfg.proactiveMinutes, 0, 0, 1440);
  if (minutes <= 0) return;
  proactiveTimer = setInterval(() => {
    void speakProactively();
  }, 60_000);
}

function stopProactive() {
  if (proactiveTimer) {
    clearInterval(proactiveTimer);
    proactiveTimer = 0;
  }
}

async function speakProactively() {
  const minutes = number(state.cfg.proactiveMinutes, 0, 0, 1440);
  if (minutes <= 0 || state.ws !== 'open') return;
  // The hazard draw. 1/N per minute means "once every N minutes on average".
  if (Math.random() >= 1 / Math.max(1, minutes)) return;

  const now = Date.now();
  const cutoff = now - minutes * 60_000;
  const cooldown = number(state.cfg.cooldownSec, 5, 0, 600) * 1000;
  const candidates = [...state.groups.values()].filter((group) => {
    const id = String(group.id);
    return (group.lastAt || 0) >= cutoff &&
      !state.busy.has(id) &&
      now - (state.lastAnswer.get(id) || 0) >= cooldown;
  });
  if (candidates.length === 0) return;

  const group = candidates[Math.floor(Math.random() * candidates.length)];
  const groupID = String(group.id);
  const turns = number(state.cfg.contextTurns, 8, 0, 40);

  state.busy.add(groupID);
  state.lastAnswer.set(groupID, now);
  try {
    const history = await loadHistory(groupID, turns);
    const system = proactivePromptFor(groupID, group.name);
    const cue = '（没有人在问你。接着上面的话题，主动说一句。）';
    const maxChars = number(state.cfg.replyMaxChars, 300, 20, 2000);
    let res = await request('llm.chat', { text: cue, system, history });
    let reply = tidyReply(res && res.text, maxChars);
    if (!reply) {
      // Same empty-content retry as the answering path: a silent proactive tick is
      // indistinguishable from a bot that has stopped working.
      note(`群 ${groupID} 主动开口的回复是空的，重试一次`);
      res = await request('llm.chat', { text: cue, system, history });
      reply = tidyReply(res && res.text, maxChars);
    }
    if (!reply) return;
    // The mood tag never reaches the group here either. Before this the proactive path
    // skipped splitStickerTag entirely, so a tag the model added on its own initiative
    // would have been pasted into the group verbatim - and it never sent the sticker it
    // named, which is half of what makes a line look typed by a person.
    const parsed = splitStickerTag(reply);
    const say = parsed.text || reply;
    if (!say) return;
    // No quote: there is no question to quote, and a reply segment needs a
    // message_seq the model's line does not have.
    await sendGroupReply(groupID, null, say);
    await remember(groupID, group.name, null, say, turns);
    note(`在群 ${groupID} 主动说了一句（${Array.from(say).length} 字${parsed.tag ? "，情绪：" + parsed.tag : "，无表情标记"}）`);
    await maybeSendSticker(groupID, parsed.tag);
  } catch (err) {
    state.counts.errors += 1;
    note(`群 ${groupID} 主动开口失败：${(err && err.message) || err}`);
  } finally {
    state.busy.delete(groupID);
  }
}

/**
 * Watches the saved settings and applies them to the RUNNING bot.
 *
 * Without this the plugin read its settings once, at startup, and the market's "保存
 * 配置" changed only the file - so an edit appeared to do nothing until the whole pet
 * was restarted. That is the exact shape of the report "I set it to reply to
 * everything, and it still only answers @": the dashboard showed the SAVED values
 * (the workshop re-reads them), while the frame kept the ones it had loaded.
 *
 * A 10s poll is enough: `config.get` is a small local file read, nothing here touches
 * the network, and a settings change is not a realtime event. A change to the address
 * or the token re-dials; a change to the trigger rules or the proactive interval takes
 * effect on the next message.
 */
const CONFIG_POLL_MS = 10_000;
let configTimer = 0;
/** The settings the bot is actually running with, as a comparable string. */
let appliedConfig = '';

function startConfigWatch() {
  if (configTimer) return;
  configTimer = setInterval(() => {
    void refreshConfig();
  }, CONFIG_POLL_MS);
}

async function refreshConfig() {
  if (!granted.has('plugin.config')) return;
  let values = null;
  try {
    const res = await request('config.get', {});
    values = (res && res.values) || {};
  } catch {
    return;
  }
  const next = { ...DEFAULTS, ...values };
  const signature = JSON.stringify(next);
  if (signature === appliedConfig) return;
  const previous = state.cfg;
  appliedConfig = signature;
  state.cfg = next;

  // A new address or token means the socket is pointed at the wrong place.
  if (next.server !== previous.server || next.accessToken !== previous.accessToken) {
    const endpoints = endpointsFor(next.server, next.accessToken);
    state.base = endpoints.base;
    state.eventUrl = endpoints.eventUrl;
    try {
      await request('ws.open', { url: state.eventUrl, token: next.accessToken });
      note('配置已更新：地址或令牌变了，正在重新连接');
    } catch (err) {
      note(`配置已更新，但重连失败：${(err && err.message) || err}`);
    }
  } else {
    note('配置已更新并生效');
  }

  if (next.proactiveMinutes !== previous.proactiveMinutes) {
    startProactive();
  }
  if (view === 'workshop') renderFacts(next);
}

/**
 * The system prompt for a line nobody asked for.
 *
 * The rules are written against a failure that took real testing to find: without
 * "必须接住群友聊的那件具体的事", a proactive line drifts into stage directions about
 * itself ("我先去囤点米饭") instead of joining the conversation.
 *
 * A line saying "最后一条是提示语，不是群友说的话" was tried and REMOVED: with it the
 * model concluded it had not seen the room at all and answered "没看到你们刚才聊啥".
 * Telling it which message is a stage direction is worse than leaving the cue as one.
 */
function proactivePromptFor(groupID, groupName) {
  const maxChars = number(state.cfg.replyMaxChars, 300, 20, 2000);
  const persona = String(state.cfg.persona || '').trim();
  return [
    persona || DEFAULT_PERSONA,
    '',
    '规则：',
    `- 你在 QQ 群「${groupName || groupID}」里，上面几条是群友刚才的聊天记录。`,
    '- 没有人 @ 你、也没有人在提问：是你自己想插一句。',
    '- 必须接住群友聊的那件具体的事（谁在说、说了什么），说一句自己的看法、追问或者吐槽；不要泛泛感慨，也不要编造记录里没出现的时间、地点、人。',
    '- 不复述别人的话，不总结，不解释你为什么开口，也不提「插话」「接话」这件事，直接说内容。',
    `- 最多 ${maxChars} 字，简体中文口语，不要 Markdown、不要列表。`,
    STICKER_INSTRUCTION,
    `- 现在是 ${new Date().toLocaleString('zh-CN', { hour12: false })}。`,
  ].join('\n');
}

/** Groups a message names: Milky reports the group's name in the event. */
function groupNameOf(data) {
  const group = data.group || {};
  return String(group.group_name || group.name || '').trim();
}

// --- B 站联动（共享托盘） ----------------------------------------------------
//
// 两个插件之间只有 L 形的一条路：宿主的小托盘（`plugin.share`）。分工是刻意的 ——
//
//   · B 站插件知道「这条链接的流在哪」（它有 cookie、有 wbi 签名、有画质阶梯），
//     但它**从不决定发给谁**；
//   · 这个插件知道「发给哪个群、要不要 @ 主人、多大就不发了」，但它**从不碰 B 站接口**，
//     也读不到那个 cookie。
//
// 所以视频要下到**本地**这件事落在这一侧：`storage.dir` 拿到自己的目录，
// `process.launch` 起 ffmpeg，`process.state` 每两秒问一次「下完了吗」。
const BILI_OWNER = 'com.shixiansi.plugin-bilibili';
const BILI_JOBS = 'bili-jobs';
const BILI_LINK_GAP_MS = 5 * 60 * 1000;
const BILI_NOTICE_GAP_MS = 5 * 60 * 1000;
/**
 * 下载用的 UA —— **故意不是浏览器 UA**。
 *
 * 真机实测，对同一个 `*.bilivideo.com` 直链，用 ffmpeg 请求：
 *
 *   User-Agent: UA-TEST-123                       → 200
 *   User-Agent: Mozilla/5.0 … Chrome/124 …        → **403**
 *   User-Agent: curl/8.4.0                        → **403**
 *
 * 反过来（先 Chrome 后任意 UA）结果一样，所以不是限流也不是顺序。最像的解释是：CDN 对
 * 「看起来像浏览器/已知客户端、但没带 cookie」的请求直接拒掉，而对一个它不认识的客户端
 * 正常服务。所以这里诚实地报一个自己的名字，不假装是浏览器 —— 装浏览器反而要不到文件。
 * （API 调用仍然用浏览器 UA，那边正好相反。）
 */
const BILI_DOWNLOAD_UA = 'PetPC-bili-bridge/1.0';
/** 宿主对 `process.launch` 单个参数的上限是 4096 字符；留一点余量。
 *  512 曾经是这个数，而真机的 B 站 CDN 直链有 600–700 字符 —— 于是「能起 ffmpeg、却永远
 *  指不到东西」。宿主的上限已经提到 4096，这里跟着放宽。 */
const BILI_MAX_ARG_CHARS = 4000;

async function readSharedValue(owner, name) {
  const res = await request('share.get', owner ? { owner, name } : { name });
  const raw = String((res && res.value) || '');
  return raw ? JSON.parse(raw) : null;
}

async function writeSharedValue(name, value) {
  await request('share.set', { name, value: JSON.stringify(value) });
}

/**
 * The B 站 link in one message, searched in the TEXT **and inside the card segments**.
 *
 * B 站 的分享卡片到 QQ 里不是文字，而是一个 `json` / `xml` / `light_app` 段：BV 号在
 * `meta.detail_1.qqdocurl`、`meta.news.jumpUrl` 或者 XML 的 `<url>` 里。只读 `plainText`
 * 的版本对卡片**完全没反应**——它连 `[卡片]` 都不产出，因为段类型不在它的 switch 里。
 *
 * 所以这里换一种做法：把每个非文字段里的**所有字符串**都翻出来（卡片负载是嵌套对象，
 * 或者一段被转义过的 JSON 字符串），再在它们里面找 BV 号 / b23 短链。类型无关，
 * 将来冒出第四种卡片类型也不用改这里。
 */
function collectStrings(value, out, depth) {
  if (out.length > 200 || depth > 6 || value === null || value === undefined) return out;
  if (typeof value === 'string') {
    out.push(value);
    return out;
  }
  if (Array.isArray(value)) {
    for (const item of value) collectStrings(item, out, depth + 1);
    return out;
  }
  if (typeof value === 'object') {
    for (const key of Object.keys(value)) collectStrings(value[key], out, depth + 1);
  }
  return out;
}

function biliLinkIn(text, segments) {
  const candidates = [String(text || '')];
  for (const seg of segments || []) {
    if (!seg || !seg.data || seg.type === 'text') continue;
    collectStrings(seg.data, candidates, 0);
  }
  for (const raw of candidates) {
    // A card payload is often a JSON string inside a JSON string, so escapes have to be
    // unwound before the URL can be recognised: `https:\/\/www.bilibili.com\/video\/BV…`.
    const value = String(raw).replace(/\\\//g, '/').replace(/\\u0026/gi, '&');
    // 边界是必须的：卡片负载里全是 base64/URL 噪声，`BV` + 10 位字母数字在随机串里也会命中
    // （真机上就从一条卡片里蒙出了 `BVlkbstVNrVJ`，于是群里多了一条「请求参数不对」的噪声）。
    const direct = /(?<![0-9A-Za-z])BV[0-9A-Za-z]{10}(?![0-9A-Za-z])/.exec(value);
    if (direct) return { url: `https://www.bilibili.com/video/${direct[0]}`, bvid: direct[0] };
    // b23.tv 是常见的那个，bili2233.cn 是同一套短链的另一个域名。
    const short = /https?:\/\/(?:b23\.tv|bili2233\.cn)\/[0-9A-Za-z]+/.exec(value);
    if (short) return { url: short[0], bvid: '' };
  }
  return null;
}

function biliJobID() {
  return `b${Date.now().toString(36)}${Math.floor(Math.random() * 46656).toString(36)}`;
}

/**
 * Asks the Bilibili plugin to resolve one link.
 *
 * The caps travel WITH the job: the plugin that owns the streams does not own the group,
 * so "how big is too big" has to be asked rather than assumed.
 */
async function maybeRequestBiliVideo(text, segments, groupID, senderID) {
  if (!flag(state.cfg.biliLinkReply, false)) return;
  const link = biliLinkIn(text, segments);
  if (!link) return;
  const now = Date.now();
  const lastAt = state.biliLinks.get(link.url) || 0;
  if (now - lastAt < BILI_LINK_GAP_MS) {
    note(`群 ${groupID}：这条链接 5 分钟内已经请求过了`);
    return;
  }
  state.biliLinks.set(link.url, now);
  const job = {
    id: biliJobID(),
    url: link.url,
    bvid: link.bvid,
    maxMB: number(state.cfg.biliMaxMB, 80, 1, 2048),
    maxMinutes: number(state.cfg.biliMaxMinutes, 25, 1, 300),
    at: now,
  };
  try {
    const existing = await readSharedValue(null, BILI_JOBS);
    const list = Array.isArray(existing) ? existing : [];
    await writeSharedValue(BILI_JOBS, [job, ...list].slice(0, 20));
    state.biliPending.set(job.id, { groupID, senderID, at: now, url: link.url });
    note(`群 ${groupID}：已请求解析 ${link.bvid || link.url}（job ${job.id}）`);
  } catch (err) {
    note(`写 ${BILI_JOBS} 失败：${(err && err.message) || err}`);
  }
}

/**
 * 产物文件的保留清单。
 *
 * 真机上踩到的坑：`send_group_message` 返回 ok 之后**立刻**删文件，群里那条视频却显示
 * 「已过期」—— 协议端的上传是异步的，等它去读文件时文件已经不在了。
 *
 * 所以改成「记账 + 延迟清理」：发完先把 `{key, at}` 记下来，下一次轮询时删掉超过
 * 10 分钟的。文件名没有扩展名（`storage.remove` 的 key 不允许点），`-f mp4` 已经告诉
 * ffmpeg 容器格式，协议端也不按扩展名判类型（用不存在的路径探过，三种都只说 File not found）。
 */
const BILI_FILES_KEY = 'bilivideo-files';
const BILI_KEEP_MS = 10 * 60 * 1000;

async function readVideoFiles() {
  try {
    const res = await request('storage.get', { key: BILI_FILES_KEY });
    const raw = String((res && res.value) || '');
    const list = raw ? JSON.parse(raw) : [];
    return Array.isArray(list) ? list.filter((entry) => entry && entry.key) : [];
  } catch {
    return [];
  }
}

async function rememberVideoFile(key) {
  const list = await readVideoFiles();
  list.push({ key, at: Date.now() });
  try {
    await request('storage.set', { key: BILI_FILES_KEY, value: JSON.stringify(list.slice(-40)) });
  } catch (err) {
    note(`记录产物失败：${(err && err.message) || err}`);
  }
}

/** 删掉够旧的产物。留着是为了让协议端把上传做完，不是为了占盘。 */
async function pruneVideoFiles() {
  const list = await readVideoFiles();
  if (!list.length) return;
  const now = Date.now();
  const keep = [];
  for (const entry of list) {
    if (now - Number(entry.at || 0) < BILI_KEEP_MS) {
      keep.push(entry);
      continue;
    }
    try {
      await request('storage.remove', { key: entry.key });
    } catch (err) {
      note(`清理 ${entry.key} 失败：${(err && err.message) || err}`);
    }
  }
  if (keep.length !== list.length) {
    try {
      await request('storage.set', { key: BILI_FILES_KEY, value: JSON.stringify(keep) });
    } catch {
      // 记不住就下次再清一遍，不算错。
    }
  }
}
/** Drains the result tray and announces recommendations. */
async function pollBridge() {
  if (state.bridgeBusy || !state.started) return;
  if (!flag(state.cfg.biliLinkReply, false) && !String(state.cfg.biliRecommendGroup || '').trim()) return;
  state.bridgeBusy = true;
  try {
    // 清理够旧的产物：这里而不是发完就删，见 BILI_FILES_KEY 的注释。
    await pruneVideoFiles();
    // 顺手扫掉很久没有回音的待办：结果丢过一次（共享值超限那次），那条待办就再也不会
    // 被消费，留着只会越积越多。
    const nowMs = Date.now();
    for (const [id, entry] of state.biliPending) {
      if (nowMs - Number(entry.at || 0) > 30 * 60 * 1000) state.biliPending.delete(id);
    }
    if (state.biliPending.size || flag(state.cfg.biliLinkReply, false)) {
      const results = await readSharedValue(BILI_OWNER, 'bili-results');
      for (const result of Array.isArray(results) ? results : []) {
        if (!result || !result.id || state.biliSeenResults.includes(result.id)) continue;
        state.biliSeenResults.push(result.id);
        if (state.biliSeenResults.length > 40) state.biliSeenResults.shift();
        // Anything older than this session's start is stale: announcing a video from
        // yesterday's job the moment the bot reconnects would be worse than losing it.
        if (result.at && state.bridgeStartedAt && result.at < state.bridgeStartedAt) continue;
        await onBiliResult(result);
      }
    }
    if (String(state.cfg.biliRecommendGroup || '').trim()) {
      const recommends = await readSharedValue(BILI_OWNER, 'recommend');
      for (const entry of Array.isArray(recommends) ? recommends : []) {
        if (!entry || !entry.bvid) continue;
        const id = `${entry.bvid}@${entry.at}`;
        if (state.biliSeenRecommends.includes(id)) continue;
        state.biliSeenRecommends.push(id);
        if (state.biliSeenRecommends.length > 40) state.biliSeenRecommends.shift();
        if (entry.at && state.bridgeStartedAt && entry.at < state.bridgeStartedAt) continue;
        await announceRecommend(entry);
      }
    }
  } catch (err) {
    note(`B 站联动轮询失败：${(err && err.message) || err}`);
  } finally {
    state.bridgeBusy = false;
  }
}

/** One answered job: download it, or say why not. */
async function onBiliResult(result) {
  const id = String(result.id);
  const pending = state.biliPending.get(id);
  if (!pending) return;
  state.biliPending.delete(id);
  const groupID = pending.groupID;
  const link = result.bvid ? `https://www.bilibili.com/video/${result.bvid}` : '';
  if (!result.ok) {
    // 失败就**忘掉这条链接**：5 分钟的去重是为了防刷屏，不是为了让「刚才那次没成功」
    // 也一起被禁掉 5 分钟。真机上正是这样卡住过一次重试。
    if (pending.url) state.biliLinks.delete(pending.url);
    // 「这不是视频」不是用户的错，也不值得在群里说一句：多半是我的正则从卡片噪声里
    // 蒙出了一个 BV 号（真机：BVlkbstVNrVJ → 请求参数不对）。记日志就够了。
    if (result.notVideo || /没认出 BV 号/.test(String(result.reason || ''))) {
      note(`群 ${groupID}：${result.bvid || '那段文本'} 不是视频，静默忽略`);
      return;
    }
    await notifyGroupThrottled(groupID, `这条视频没法直接发：${result.reason || '未知原因'}${result.title ? `\n标题：${result.title}` : ''}${link ? `\n${link}` : ''}`);
    return;
  }
  const muxed = await runFfmpeg(result);
  if (!muxed.ok) {
    note(`群 ${groupID}：${result.bvid} 没发成视频 —— ${muxed.reason}`);
    await notifyGroupThrottled(groupID, `${muxed.reason}${result.title ? `\n标题：${result.title}` : ''}${link ? `\n${link}` : ''}`);
    return;
  }
  const sent = await sendBiliVideo(groupID, result, muxed.path, muxed.key);
  // 产物已经在 `runFfmpeg` 里记过账了（每次尝试都记，失败的那次可能是 0 字节），
  // 这里不再重复记；10 分钟后由 `pruneVideoFiles` 收走。
  if (!sent) return;
}

/**
 * ffmpeg: download the two tracks and mux them, without re-encoding (`-c copy`).
 *
 * Everything here is bounded by facts the host enforces: one argument is at most 512
 * characters, and `process.launch` does not wait. So the URL length is checked here
 * (a signed B 站 CDN URL can be long) and completion is POLLED rather than awaited -
 * awaiting would freeze this frame's message handling for a minute.
 */
/**
 * ffmpeg 的等待预算，按**预估体积**给：最少 90 秒，最多 15 分钟。
 *
 * 原来写死 90 秒。真机上 59 MB 的 720p 在普通家宽下就要两三分钟，于是必然超时，
 * 用户看到的就是「下载超过 90 秒」——预算按体积给才合理：大约按 250 KB/s 的保守速度算，
 * 小文件仍走 90 秒下限，大文件自动放宽。
 */
function ffmpegBudgetMs(sizeBytes) {
  const sizeMB = Math.max(0, Number(sizeBytes) || 0) / 1048576;
  return Math.min(15 * 60 * 1000, Math.max(90 * 1000, Math.round(sizeMB * 4000)));
}

/**
 * 用**体积**判断产物能不能发，而不是用时间。
 *
 * xunlu-core 就是这么做的（`fs.statSync(resultPath).size` 与上限比），因为它手里已经有
 * 预估字节（`estimateMuxedVideoBytes`）。时间不是判据：同样 60 MB，一条宽带要四分钟、
 * 一条千兆四十秒，用秒数卡必然一边误杀一边白等。
 *
 * 三种情况拒发（都改成发链接 + 一句原因）：
 *   · 文件是空的 —— ffmpeg 退 0 但没写出东西；
 *   · 只有预估的一半不到 —— 下载被截断，发出去也是坏视频；
 *   · 超过 job 给的上限 —— 预估不准时由真实体积兜底。
 */
async function verifyMuxedSize(key, result) {
  let stat = null;
  try {
    stat = await request('storage.stat', { key });
  } catch (err) {
    // 问不到大小不算失败：ffmpeg 已经退 0，文件就在那儿。宁可信它。
    note(`查不到 ${key} 的大小：${(err && err.message) || err}`);
    return { ok: true, bytes: 0 };
  }
  const bytes = Number((stat && stat.bytes) || 0);
  if (!stat || !stat.exists || bytes <= 0) {
    return { ok: false, reason: 'ffmpeg 说成功了，但产物是空的，只发链接。' };
  }
  const mb = (value) => `${Math.round((Number(value) || 0) / 1048576 * 10) / 10} MB`;
  const estimate = Number(result.sizeBytes) || 0;
  if (estimate > 0 && bytes < estimate * 0.5) {
    return { ok: false, bytes, reason: `产物只有 ${mb(bytes)}，预估 ${mb(estimate)}，像是没下完，只发链接。` };
  }
  const cap = Number(result.maxMB) || 0;
  if (cap > 0 && bytes > cap * 1048576 * 1.05) {
    return { ok: false, bytes, reason: `产物 ${mb(bytes)} 超过上限 ${cap} MB，只发链接。` };
  }
  return { ok: true, bytes };
}

/** 系统自带的 curl（Windows 10 1803 起随系统）。路径由自己的私有目录推盘符得到。 */
function curlPath(dir) {
  const match = /^([A-Za-z]:)/.exec(String(dir || ''));
  return match ? `${match[1]}\\Windows\\System32\\curl.exe` : '';
}

/**
 * 用 curl 下一条流到本地。**下载归 curl，ffmpeg 只负责合并**。
 *
 * 上一版让 ffmpeg 自己当 HTTP 客户端，于是网络问题全变成 ffmpeg 问题：UA、Referer、
 * 读超时、断线重连都要用参数表达，一条命令 38 个参数，直接撞穿宿主的 32 个上限。
 * curl 这些都有现成开关，退出码也有明确含义（6/7 解析或连接失败、28 超时、22 HTTP 错）。
 */
async function downloadStream(dir, key, url, label, budgetMs) {
  const curl = curlPath(dir);
  if (!curl) return { ok: false, key, reason: `找不到 curl.exe（盘符未知）` };
  const out = `${dir}\\${key}`;
  const args = [
    '-sS', '-L', '--fail',
    '--max-time', '900',
    '--retry', '2', '--retry-delay', '2',
    '-A', BILI_DOWNLOAD_UA,
    '-e', 'https://www.bilibili.com/',
    '-o', out,
    url,
  ];
  let pid = 0;
  try {
    const launched = await request('process.launch', { path: curl, args });
    pid = Number((launched && launched.pid) || 0);
  } catch (err) {
    return { ok: false, key, reason: `${label} 启动 curl 失败：${(err && err.message) || err}` };
  }
  if (!pid) return { ok: false, key, reason: `${label} curl 没起来` };

  const pollMs = typeof state.biliPollMs === 'number' ? state.biliPollMs : 2000;
  // 预算按预估体积给（ffmpegBudgetMs），curl 自己还有 --max-time 900 兜底。
  const deadline = Date.now() + Math.max(Number(budgetMs) || 0, 5 * 60 * 1000);
  let lastBytes = -1;
  let lastGrowth = Date.now();
  while (Date.now() < deadline) {
    await sleep(pollMs);
    let status = null;
    try {
      status = await request('process.state', { pid });
    } catch {
      continue;
    }
    if (status && status.known && !status.running) {
      if (Number(status.exitCode) !== 0) {
        return { ok: false, key, reason: `${label} curl 退出码 ${status.exitCode}` };
      }
      const stat = await request('storage.stat', { key }).catch(() => null);
      const bytes = Number((stat && stat.bytes) || 0);
      if (!stat || !stat.exists || bytes <= 0) {
        return { ok: false, key, reason: `${label} 下载结果是空文件` };
      }
      return { ok: true, key, path: out, bytes };
    }
    // 进度看门狗：45 秒没涨就认定这条连接废了（真机：死连接两分钟只写 0 字节）。
    const stat = await request('storage.stat', { key }).catch(() => null);
    const bytes = Number((stat && stat.bytes) || 0);
    if (bytes > lastBytes) {
      lastBytes = bytes;
      lastGrowth = Date.now();
    } else if (Date.now() - lastGrowth > 45 * 1000) {
      return { ok: false, key, reason: `${label} 连接卡住了（45 秒没有数据）` };
    }
  }
  return { ok: false, key, reason: `${label} 下载超过 15 分钟` };
}

/** 把两条本地流合成一个 mp4。**只有这一步用 ffmpeg**，参数少到不会再撞上限。 */
async function muxStreams(dir, key, videoPath, audioPath) {
  const ffmpeg = String(state.cfg.ffmpegPath || '').trim();
  const out = `${dir}\\${key}`;
  const args = audioPath
    ? ['-y', '-i', videoPath, '-i', audioPath, '-map', '0:v:0', '-map', '1:a:0', '-c', 'copy', '-f', 'mp4', out]
    : ['-y', '-i', videoPath, '-c', 'copy', '-f', 'mp4', out];
  let pid = 0;
  try {
    const launched = await request('process.launch', { path: ffmpeg, args });
    pid = Number((launched && launched.pid) || 0);
  } catch (err) {
    return { ok: false, reason: `启动 ffmpeg 失败：${(err && err.message) || err}` };
  }
  if (!pid) return { ok: false, reason: 'ffmpeg 没起来' };

  const pollMs = typeof state.biliPollMs === 'number' ? state.biliPollMs : 2000;
  // 本地文件合成是纯 I/O，几十秒足够；这里给 3 分钟纯粹是卡死兜底。
  const deadline = Date.now() + 3 * 60 * 1000;
  while (Date.now() < deadline) {
    await sleep(pollMs);
    let status = null;
    try {
      status = await request('process.state', { pid });
    } catch {
      continue;
    }
    if (status && status.known && !status.running) {
      if (Number(status.exitCode) !== 0) return { ok: false, reason: `ffmpeg 退出码 ${status.exitCode}` };
      return { ok: true, path: out, key };
    }
  }
  return { ok: false, reason: 'ffmpeg 合成超过 3 分钟' };
}

async function runFfmpeg(result) {
  const ffmpeg = String(state.cfg.ffmpegPath || '').trim();
  if (!ffmpeg) return { ok: false, reason: '没配置 ffmpeg 路径，只发链接。' };
  const videoUrl = String((result.video && result.video.url) || '');
  const audioUrl = String((result.audio && result.audio.url) || '');
  if (!videoUrl) return { ok: false, reason: '这条视频没有可下载的地址。' };
  let dir = '';
  try {
    const res = await request('storage.dir', {});
    dir = String((res && res.dir) || '');
  } catch (err) {
    return { ok: false, reason: `拿不到自己的目录：${(err && err.message) || err}` };
  }
  if (!dir) return { ok: false, reason: '拿不到自己的目录，发不了文件。' };

  // 候选：主地址一次，备用 CDN 再一次（CDN 抽风是按节点来的）。
  const candidates = [{ video: videoUrl, audio: audioUrl, label: '主地址' }];
  const backupVideo = String(((result.video && result.video.backups) || [])[0] || '');
  const backupAudio = String(((result.audio && result.audio.backups) || [])[0] || '');
  if (backupVideo) candidates.push({ video: backupVideo, audio: backupAudio || audioUrl, label: '备用 CDN' });

  const budget = ffmpegBudgetMs(result.sizeBytes);
  const stamp = Date.now().toString(36);
  let lastReason = '';
  for (let index = 0; index < candidates.length; index += 1) {
    const candidate = candidates[index];
    const suffix = index ? `b${index}` : '';
    const videoKey = `bili${stamp}${suffix}v`;
    const audioKey = `bili${stamp}${suffix}a`;
    const outKey = `bilivideo${stamp}${suffix}`;
    const video = await downloadStream(dir, videoKey, candidate.video, `${candidate.label}视频`, budget);
    await rememberVideoFile(videoKey);
    if (!video.ok) {
      lastReason = video.reason;
      note(`群里的视频第 ${index + 1} 次下载失败（${lastReason}）`);
      continue;
    }
    let audio = { ok: true, path: '' };
    if (candidate.audio) {
      audio = await downloadStream(dir, audioKey, candidate.audio, `${candidate.label}音频`, budget);
      await rememberVideoFile(audioKey);
    }
    if (!audio.ok) {
      lastReason = audio.reason;
      note(`群里的视频第 ${index + 1} 次下载失败（${lastReason}）`);
      continue;
    }
    const muxed = await muxStreams(dir, outKey, video.path, audio.path || '');
    await rememberVideoFile(outKey);
    // 两条中间文件用完就删：它们已经没用了，留着只是占盘。
    for (const key of [videoKey, audioKey]) {
      if (key) await request('storage.remove', { key }).catch(() => {});
    }
    if (!muxed.ok) {
      lastReason = muxed.reason;
      note(`群里的视频第 ${index + 1} 次合成失败（${lastReason}）`);
      continue;
    }
    const check = await verifyMuxedSize(outKey, result);
    if (!check.ok) {
      lastReason = check.reason;
      note(`群里的视频第 ${index + 1} 次体积验收不过（${lastReason}）`);
      continue;
    }
    return { ok: true, path: muxed.path, key: outKey, bytes: check.bytes };
  }
  const sizeMB = Math.round((Number(result.sizeBytes) || 0) / 1048576);
  return { ok: false, reason: `${lastReason}（预估 ${sizeMB} MB），只发链接。` };
}

async function sendBiliVideo(groupID, result, path, _key) {
  const owner = String(state.cfg.ownerQQ || '').trim();
  const atOwner = flag(state.cfg.biliLinkAtOwner, true) && owner;
  const minutes = Math.round((Number(result.duration) || 0) / 60);
  // `quality` 是插件算好的画质名（720p / 480p…）；老结果里没有就退回 qn。
  const quality = result.kind === 'dash' ? (result.quality || `qn ${result.qn}`) : '单文件';
  // 正文里**不放链接**：群里往往还有别的「B 站链接解析」机器人，看到 URL 就会自己再解析
  // 一遍，于是我们发一条视频、它回一张卡片。链接只在「发不出视频」的说明里出现。
  const text = `【B 站】${result.title || result.bvid}\nUP：${result.up || '未知'} · ${minutes} 分钟 · ${quality}`;
  const message = [];
  if (atOwner) message.push({ type: 'at', data: { user_id: Number(owner) } });
  message.push({ type: 'text', data: { text } });

  /**
   * 三种 `uri` 形式，按「这个协议端最可能接受的」排：
   *
   *   file://C:/…    ← 首选。真机两条报错拼起来就是这个：`file:///C:/…` 被截成
   *                    `/C:/…`（多一个前导斜杠 → File not found），裸路径没有 scheme
   *                    （→ Unsupported URI scheme）。也就是说它按 `file://` 前缀截断后
   *                    把剩下的部分直接当路径，所以「两个斜杠 + 盘符」才是对的。
   *   file:///C:/…   ← 规范形式，给按 URL 解析的实现（u.Path 带前导斜杠的那种）。
   *   裸路径          ← 给根本不看 scheme、直接 stat 的实现。
   *
   * 一个 `video` 段只能带一个 uri，所以每次重试都重建整条消息。
   */
  const slashed = path.replace(/\\/g, '/');
  const forms = [`file://${slashed}`, `file:///${slashed}`, path];
  let lastError = null;
  for (const uri of forms) {
    try {
      const res = await api('send_group_message', { group_id: Number(groupID), message: [...message, { type: 'video', data: { uri } }] });
      state.counts.replies += 1;
      // message_seq 记进日志：协议端（Yogurt）的日志里也是这个号，两边对得上才查得动
      // 「视频显示已过期」这类问题。
      const seq = res && res.message_seq ? `，seq ${res.message_seq}` : '';
      note(`群 ${groupID}：已发出视频 ${result.bvid}（uri=${uri}${seq}）`);
      return true;
    } catch (err) {
      lastError = (err && err.message) || String(err);
      note(`发视频失败（uri=${uri}）：${lastError}`);
    }
  }
  note(`文件留在 ${path}，可以直接手动发一次看看`);
  // 只有这条「发不出去」的说明里才带链接 —— 这时候链接是唯一的交付物。
  const link = result.bvid ? `\nhttps://www.bilibili.com/video/${result.bvid}` : '';
  await notifyGroupThrottled(groupID, `视频发不出去：${lastError}${link}`);
  return false;
}

/** A one-line explanation in the group, at most once per five minutes per group. */
async function notifyGroupThrottled(groupID, text) {
  const now = Date.now();
  if (now - (state.biliNoticeAt.get(groupID) || 0) < BILI_NOTICE_GAP_MS) {
    note(`群 ${groupID}：5 分钟内已经解释过一次，这次不重复`);
    return;
  }
  state.biliNoticeAt.set(groupID, now);
  try {
    await api('send_group_message', { group_id: Number(groupID), message: [{ type: 'text', data: { text } }] });
  } catch (err) {
    note(`发说明失败：${(err && err.message) || err}`);
  }
}

/** A recommendation from the Bilibili plugin: text + @ the owner, never a video. */
async function announceRecommend(entry) {
  const groupID = String(state.cfg.biliRecommendGroup || '').trim();
  if (!groupID) return;
  const owner = String(state.cfg.ownerQQ || '').trim();
  const message = [];
  if (flag(state.cfg.biliLinkAtOwner, true) && owner) message.push({ type: 'at', data: { user_id: Number(owner) } });
  message.push({
    type: 'text',
    data: {
      text: `【刷到值得看的】${entry.title || entry.bvid}\n${entry.why || ''}\n${entry.summary || ''}\nhttps://www.bilibili.com/video/${entry.bvid}`,
    },
  });
  try {
    await api('send_group_message', { group_id: Number(groupID), message });
    note(`群 ${groupID}：已发出 B 站推荐 ${entry.bvid}`);
  } catch (err) {
    note(`发推荐失败：${(err && err.message) || err}`);
  }
}

/** One inbound `message_receive` event. */
async function onGroupMessage(event) {
  const data = event.data || {};
  if (data.message_scene !== 'group') return;
  const groupID = String(data.peer_id || '');
  if (!groupID) return;
  const selfID = String(event.self_id || state.selfID || '');
  const senderID = String(data.sender_id || '');
  // The protocol side reports the bot's OWN messages too (Yogurt's config has
  // `reportSelfMessage`), so this is not an optimisation: without it every answer
  // would be answered.
  if (selfID && senderID === selfID) return;
  if (!groupAllowed(groupID)) return;

  const segments = Array.isArray(data.segments) ? data.segments : [];
  // The quote and any forwarded block are resolved here rather than in plainText:
  // one needs the event's own payload, the other an API round trip.
  const enriched = await enrichSegments(segments, selfID, groupID);
  const raw = enriched.text;
  const mentioned = mentionsBot(segments, selfID);
  // The room is alive whether or not this message is for the bot: the proactive path
  // decides from this index, and an unanswered message is exactly the evidence it
  // needs that there is a conversation worth joining.
  touchGroup(groupID, groupNameOf(data));
  // A link is worth resolving whoever posted it and whether or not the bot is being
  // addressed, so this sits BEFORE the chat trigger rules - and it is not awaited, so a
  // long round trip cannot delay the answer to a real question. The SEGMENTS travel with
  // the text because B 站 的分享卡片把链接放在段里，纯文本里没有。
  void maybeRequestBiliVideo(raw, segments, groupID, senderID);
  if (!shouldAnswer(raw, mentioned)) {
    // SAY why it stayed silent, once per group per minute.
    //
    // This line exists because its absence cost an afternoon: the market edits the
    // STORED settings, the running frame kept the ones it read at startup, and the
    // only observable difference was "it answers @ but not anything else" - which
    // looks exactly like a broken trigger rule rather than a stale config. A bot
    // that explains its own silence is a bot you can debug from a dashboard.
    const now = Date.now();
    const last = state.ignoredAt.get(groupID) || 0;
    if (now - last > 60_000) {
      state.ignoredAt.set(groupID, now);
      note(`群 ${groupID}：这条没被 @，按当前设置不回（atOnly=${flag(state.cfg.atOnly, true)}, 插话概率=${number(state.cfg.replyChance, 0, 0, 100)}%）`);
    }
    return;
  }

  const ask = stripPrefix(raw);
  if (!ask) return;

  state.counts.asked += 1;
  const groupName = groupNameOf(data);
  const asker = speakerOf(data);

  if (state.busy.has(groupID)) {
    note(`群 ${groupID} 上一条还没答完，忽略这条`);
    return;
  }
  const cooldown = number(state.cfg.cooldownSec, 5, 0, 600) * 1000;
  const last = state.lastAnswer.get(groupID) || 0;
  if (cooldown > 0 && Date.now() - last < cooldown) {
    note(`群 ${groupID} 冷却中，忽略这条`);
    return;
  }

  state.busy.add(groupID);
  state.lastAnswer.set(groupID, Date.now());
  try {
    const turns = number(state.cfg.contextTurns, 8, 0, 40);
    const history = await loadHistory(groupID, turns);
    // Diagnostic: a message that LOOKS like it carries a picture must say how many
    // URLs were collected. Without this line "the model says it cannot see the image"
    // is indistinguishable from "no image was ever attached", and the two need
    // completely different fixes.
    const images = imagesOf([...(segments || []), ...enriched.quoteSegments]);
    const pictureSegments = [...(segments || []), ...enriched.quoteSegments].filter((seg) => {
      if (!seg) return false;
      if (seg.type === 'image') return true;
      return seg.type === 'reply' &&
        (seg.data && Array.isArray(seg.data.segments)) &&
        seg.data.segments.some((inner) => inner && inner.type === 'image');
    });
    if (pictureSegments.length) {
      note(`收到含图片的消息：采集到 ${images.length} 张（visionModel=${String(state.cfg.visionModel || '').trim() || '未设置'}）`);
    }
    // The speaker's name travels WITH the question, exactly as it does in the history
    // (`昵称：内容`). It used to be added only when remembering, so the prompt said
    // "消息前面会带上说话人的昵称" and then handed over a question with no name in
    // front of it: the model answered "你们" instead of 阿棠, and a group member who
    // does not know who just spoke is the tell that it is not reading the room.
    const asked = `${asker}：${ask}`;
    const system = systemPromptFor(groupID, groupName);
    const maxChars = number(state.cfg.replyMaxChars, 300, 20, 2000);
    let res = await askModel(asked, system, history, images);
    let reply = tidyReply(res && res.text, maxChars);
    if (!reply) {
      // A reasoning model can spend the whole token budget on reasoning and return an
      // EMPTY content with finish_reason "stop" - seen live on qwen3.8-27b. One more
      // draw is cheap and usually answers; saying nothing in a group is worse than a
      // mediocre line, because nobody can tell it apart from a broken bot.
      note(`群 ${groupID} 的回复是空的，重试一次`);
      res = await askModel(asked, system, history, images);
      reply = tidyReply(res && res.text, maxChars);
    }
    if (!reply) {
      note(`群 ${groupID} 的回复还是空的，没有发送`);
      return;
    }
    // The mood tag is stripped BEFORE the text is sent: it is a protocol between the model and this file, not something a group should read.
    const parsed = splitStickerTag(reply);
    const say = parsed.text || reply;
    await sendGroupReply(groupID, data.message_seq, say);
    await remember(groupID, groupName, asked, say, turns);
    note(`群 ${groupID} 回复了 ${asker}（${Array.from(say).length} 字${parsed.tag ? "，情绪：" + parsed.tag : "，无表情标记"}）`);
    await maybeSendSticker(groupID, parsed.tag);
  } catch (err) {
    state.counts.errors += 1;
    // The host's refusal is already a readable sentence ("「X」还没有可用的大模型配置…");
    // it goes into the log rather than into the group, because a group full of
    // people should not be told how the bot is configured.
    note(`群 ${groupID} 回答失败：${(err && err.message) || err}`);
  } finally {
    state.busy.delete(groupID);
  }
}

/** One inbound text frame from the socket. */
function onSocketFrame(text) {
  state.counts.frames += 1;
  let event = null;
  try {
    event = JSON.parse(text);
  } catch {
    note('收到一个不是 JSON 的帧，已忽略');
    return;
  }
  if (!event || typeof event !== 'object') return;
  if (event.self_id && !state.selfID) state.selfID = String(event.self_id);
  switch (event.event_type) {
    case 'message_receive':
      // Private messages are the OWNER's import channel (see onPrivateMessage);
      // group messages are the conversation channel. Both arrive as message_receive.
      if (event.data && event.data.message_scene === 'group') void onGroupMessage(event);
      else void onPrivateMessage(event);
      break;
    case 'bot_offline':
      note(`协议端报告机器人下线：${(event.data && event.data.reason) || '未说明'}`);
      break;
    default:
      // Every other Milky event is out of scope for this plugin: reacting to them
      // would mean claiming behaviour nothing here implements.
      break;
  }
}

// --- 协议端（可选自动启动）-----------------------------------------------------

/**
 * How long the protocol side has to answer a `get_login_info` before it counts as
 * "not running". Short on purpose: this sits in front of the connection, so the whole
 * probe is a startup cost, and a server that is up answers a local HTTP request in
 * milliseconds.
 */
const CLIENT_PROBE_TIMEOUT_MS = 1500;

/**
 * How long to wait after starting the protocol side before dialling.
 *
 * A freshly started Yogurt needs a moment to bind its port and load its account. Dialling
 * immediately would fail, and the host's retry ladder would then spend its first (short)
 * step on a connection that could never have worked.
 */
const CLIENT_STARTUP_GRACE_MS = 2000;

/**
 * Whether THIS page has already tried to start the protocol side.
 *
 * One attempt per page lifetime, and the flag is checked before the call rather than
 * after it: a plugin frame is rebuilt on every plugin update, and a bot that re-launched
 * Yogurt on every rebuild would fill the desktop with copies the user never asked for.
 */
let clientLaunchTried = false;

/**
 * True when something ANSWERS at the protocol side's API.
 *
 * It is deliberately not api(): api() throws when the reply carries `status: "failed"`,
 * and a protocol side that is running but not logged in yet answers exactly that. Only a
 * transport-level failure - nothing listening, connection refused, the probe's own
 * deadline - means "the program is not there", which is the only question this asks.
 * Starting a second copy because the first one has not scanned a QR code yet would be
 * the worst outcome of getting this wrong.
 */
async function protocolClientReachable() {
  const headers = { accept: 'application/json', 'content-type': 'application/json' };
  if (state.cfg.accessToken) headers.authorization = `Bearer ${state.cfg.accessToken}`;
  try {
    await requestWithTimeout('net.fetch', {
      method: 'POST',
      url: `${state.base}/api/get_login_info`,
      body: '{}',
      headers,
    }, CLIENT_PROBE_TIMEOUT_MS);
    return true;
  } catch (err) {
    // The reason is worth a line: "not declared in netHosts" and "connection refused"
    // both mean "not reachable" here but need completely different fixes.
    note(`探测协议端失败：${(err && err.message) || err}`);
    return false;
  }
}

/**
 * Starts the protocol side if it is not already running and the user asked for it.
 *
 * Called ONCE per page, before the socket is dialled. Each of the four outcomes is a
 * distinct log line, because the difference between "you did not turn it on", "you did
 * not give me a path", "I started it" and "it would not start" is exactly what a user
 * staring at "未连接" needs to know.
 */
async function ensureProtocolClient() {
  if (await protocolClientReachable()) return;

  if (!flag(state.cfg.autoStartClient, false)) {
    note('协议端没响应：没开启自动启动（autoStartClient 关），不改动它');
    return;
  }
  const path = String(state.cfg.clientPath || '').trim();
  if (!path) {
    note('协议端没响应：自动启动已开启，但「协议端可执行文件」路径是空的');
    return;
  }
  if (!granted.has('process')) {
    note('协议端没响应：缺少 process 权限，无法启动本机程序');
    return;
  }
  if (clientLaunchTried) {
    note('协议端没响应：本次已经尝试过启动，不再重复拉起');
    return;
  }
  clientLaunchTried = true;
  try {
    const res = await request('process.launch', { path, args: argsOf(state.cfg.clientArgs) });
    const pid = (res && res.pid) || 0;
    note(`已启动协议端客户端（pid ${pid}）`);
  } catch (err) {
    // The host's refusal is already a readable sentence ("process.launch 的 path 必须是
    // 绝对路径：…"), and it is shown verbatim: the user has to fix the field it names.
    note(`启动客户端失败：${(err && err.message) || err}`);
    return;
  }
  await sleep(CLIENT_STARTUP_GRACE_MS);
}

// --- connection --------------------------------------------------------------

function onSocketState(payload) {
  const next = (payload && payload.state) || 'closed';
  state.ws = next;
  state.wsError = (payload && payload.error) || '';
  note(`WebSocket ${next}${state.wsError ? `（${state.wsError}）` : ''}`);
  if (next === 'open') void learnIdentity();
  schedulePersist();
}

/** Asks the protocol side who we are, so the dashboard can show it. */
async function learnIdentity() {
  try {
    const info = await api('get_login_info', {});
    if (info && info.uin) {
      state.selfID = String(info.uin);
      state.selfName = String(info.nickname || '');
      note(`已登录：${state.selfName || '（无昵称）'} ${state.selfID}`);
      schedulePersist();
    }
  } catch (err) {
    note(`读取登录信息失败：${(err && err.message) || err}`);
  }
}

/** Starts the bot: read the settings, derive the endpoints, ask the host to dial. */
async function startBot() {
  if (state.started) return;
  state.started = true;
  if (!granted.has('net.ws')) {
    note('未获授权：net.ws');
    return;
  }
  try {
    const res = await request('config.get', {});
    const values = (res && res.values) || {};
    state.cfg = { ...DEFAULTS, ...values };
  } catch (err) {
    note(`读取配置失败：${(err && err.message) || err}`);
  }
  const endpoints = endpointsFor(state.cfg.server, state.cfg.accessToken);
  state.base = endpoints.base;
  state.eventUrl = endpoints.eventUrl;
  appliedConfig = JSON.stringify(state.cfg);
  // Before dialling, ask whether the protocol side is even there. This is the only
  // place the client is started: it happens once, at the start of the page's life,
  // and the retry ladder below then owns the connection.
  await ensureProtocolClient();
  try {
    await request('ws.open', { url: state.eventUrl, token: state.cfg.accessToken });
    note(`正在连接 ${endpoints.eventUrl.replace(/access_token=[^&]*/, 'access_token=***')}`);
  } catch (err) {
    state.counts.errors += 1;
    note(`连接失败：${(err && err.message) || err}`);
  }
  void refreshModelSource();
  // Keep the running bot in step with the saved settings: see startConfigWatch.
  startConfigWatch();
  // 5 s beat for the Bilibili bridge: results arrive as files, and a file has no
  // event to deliver. The interval is deliberately slower than the WebSocket: the
  // bot's own replies must stay instant, the bridge's seconds do not matter.
  state.bridgeStartedAt = Date.now();
  if (state.bridgeTimer) clearInterval(state.bridgeTimer);
  state.bridgeTimer = setInterval(() => {
    void pollBridge();
  }, 5000);
  // The ticker is started from the settings, not from a constant: a user who set
  // `proactiveMinutes` to 0 must not pay for a timer that decides to do nothing
  // every minute.
  startProactive();
  if (number(state.cfg.proactiveMinutes, 0, 0, 1440) > 0) {
    note(`主动开口已开启：平均每 ${number(state.cfg.proactiveMinutes, 0, 0, 1440)} 分钟一句`);
  }
}

/** Records where the model settings would come from, for the dashboard. */
async function refreshModelSource() {
  if (!granted.has('llm.borrow')) {
    state.modelSource = state.cfg.llmModel ? `自有：${state.cfg.llmModel}` : '自有配置';
    return;
  }
  try {
    const profile = await request('llm.profile', {});
    if (profile && profile.source === 'borrowed' && profile.lender) {
      state.modelSource = `借用「${profile.lender.name}」：${profile.model || ''}`;
    } else if (profile && profile.source === 'own') {
      state.modelSource = `自有：${profile.model || state.cfg.llmModel}`;
    } else {
      state.modelSource = '未配置';
    }
  } catch (err) {
    state.modelSource = '由桌宠进程决定';
  }
}

// --- views -------------------------------------------------------------------

function applyView(surface) {
  const slot = (surface && surface.slot) || '';
  view = slot === 'background' ? 'background' : 'workshop';
  els.root.className = view === 'background' ? 'view-background' : 'view-workshop';
  els.root.dataset.view = view;
  if (els.background) els.background.hidden = view !== 'background';
  if (els.workshop) els.workshop.hidden = view !== 'workshop';
}

function setChip(el, text, tone) {
  if (!el) return;
  el.textContent = text;
  if (tone) el.dataset.state = tone;
}

const STATE_LABEL = {
  connecting: '连接中',
  open: '已连接',
  error: '连接异常（自动重试中）',
  closed: '未连接',
};

function renderFacts(cfg) {
  if (!els.facts) return;
  const atOnly = flag(cfg.atOnly, true);
  const chance = number(cfg.replyChance, 0, 0, 100);
  const proactive = number(cfg.proactiveMinutes, 0, 0, 1440);
  const rows = [
    ['协议端', String(cfg.server || DEFAULTS.server)],
    ['触发', atOnly
      ? '只有 @ 机器人（或前缀）'
      : chance <= 0
        ? '只回应 @ / 前缀（插话概率为 0）'
        : chance >= 100
          ? '每条群消息都回'
          : `每条群消息 ${chance}% 概率插话`],
    ['主动开口', proactive > 0 ? `平均每 ${proactive} 分钟一句` : '关闭'],
    ['生效的群', listOf(cfg.groupAllow).length ? listOf(cfg.groupAllow).join('、') : '所有群'],
    ['每群记忆', `${number(cfg.contextTurns, 8, 0, 40)} 条往来`],
    ['回复上限', `${number(cfg.replyMaxChars, 300, 20, 2000)} 字`],
    ['同群间隔', `${number(cfg.cooldownSec, 5, 0, 600)} 秒`],
  ];
  els.facts.replaceChildren();
  for (const [label, value] of rows) {
    const li = document.createElement('li');
    const strong = document.createElement('span');
    strong.className = 'fact-label';
    strong.textContent = label;
    const span = document.createElement('span');
    span.textContent = value;
    li.append(strong, span);
    els.facts.appendChild(li);
  }
}

function renderLog() {
  if (!els.log) return;
  els.log.replaceChildren();
  const entries = state.log.slice(-20).reverse();
  els.log.hidden = entries.length === 0;
  if (els.logEmpty) els.logEmpty.hidden = entries.length !== 0;
  for (const line of entries) {
    const li = document.createElement('li');
    li.textContent = line;
    els.log.appendChild(li);
  }
}

function renderGroups() {
  if (!els.groups || !els.groupsBody) return;
  const rows = [...state.groups.values()].sort((a, b) => (b.lastAt || 0) - (a.lastAt || 0));
  els.groupsBody.replaceChildren();
  els.groups.hidden = rows.length === 0;
  if (els.groupsEmpty) els.groupsEmpty.hidden = rows.length !== 0;
  for (const row of rows) {
    const tr = document.createElement('tr');
    const id = document.createElement('td');
    id.textContent = row.id;
    const name = document.createElement('td');
    name.textContent = row.name || '（未命名）';
    const count = document.createElement('td');
    count.textContent = String(row.count || 0);
    const last = document.createElement('td');
    last.textContent = row.lastAt
      ? new Date(row.lastAt).toLocaleString('zh-CN', { hour12: false })
      : '';
    const action = document.createElement('td');
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'ghost';
    button.textContent = '忘掉这个群';
    button.addEventListener('click', () => void forgetGroup(row));
    action.appendChild(button);
    tr.append(id, name, count, last, action);
    els.groupsBody.appendChild(tr);
  }
}

/** Deletes one group's memory. Runs in the MARKET here; the bot re-reads on the next question. */
async function forgetGroup(row) {
  if (!granted.has('storage')) return;
  try {
    await request('storage.remove', { key: historyKey(row.id) });
    state.groups.delete(String(row.id));
    await request('storage.set', {
      key: GROUPS_KEY,
      value: JSON.stringify([...state.groups.values()]),
    });
    renderGroups();
    note(`已清除群 ${row.id} 的记忆`);
  } catch (err) {
    note(`清除失败：${(err && err.message) || err}`);
  }
}

// --- 表情包管理（市场面板）---------------------------------------------------
//
// The bot fills this library (owner's private message -> vision model -> bytes in
// storage); this section is the only place a human can look at it and re-file it. It
// runs in the MARKET's process and touches exactly three storage keys:
//
//   `stickers`        the index: [{hash, tag, description}]
//   `categories`      the list a human may pick from
//   `sticker_<hash>`  the bytes - READ here, and never written or removed
//
// That last line is a promise, not an accident: "I deleted a category" must not delete
// pictures the user collected, so a delete only re-tags index rows (see
// deleteStickerCategory).
//
// LOADING IS PER PAGE ON PURPOSE. A hundred stickers at a few hundred KB each is tens of
// megabytes of base64; reading all of them to draw 24 is how a workshop tab turns into an
// out-of-memory report. Only the current page's `sticker_<hash>` keys are read, and the
// copies are dropped once the user has browsed a couple of pages away from them.

const STICKERS_KEY = 'stickers';
const CATEGORIES_KEY = 'categories';
const STICKER_BYTES_PREFIX = 'sticker_';
/** The built-in bucket. Never in `categories`, never renameable, never removable. */
const UNCATEGORIZED = '未分类';
const STICKER_FILTER_ALL = '全部';
const STICKER_PAGE_SIZE = 24;
const STICKER_TAG_MAX_CHARS = 12;

const stickerUI = {
  /** True once the index and the category list have been read at least once. */
  loaded: false,
  index: [],
  categories: [],
  page: 1,
  filter: STICKER_FILTER_ALL,
  moveTarget: UNCATEGORIZED,
  selected: new Set(),
  /** hash -> base64 for the pages the user is looking at (bounded, see below). */
  bytes: new Map(),
  /** The category whose row is in "rename" mode, or '' when none is. */
  editing: '',
  /** Incremented on every page render, so a load for a page already left stops. */
  loadToken: 0,
  bound: false,
};

/** One sticker's category: a missing or blank tag IS 未分类, never a category named "". */
function stickerTagOf(row) {
  const tag = String((row && row.tag) || '').trim();
  return tag || UNCATEGORIZED;
}

/**
 * Every category the UI may offer: the stored list first, then any tag that only the
 * index knows about.
 *
 * The second half is the answer to a real hazard, not a nicety. The vision model is
 * given a CLOSED list of ten categories and keeps producing them whatever a human does
 * here, so deleting "无语" cannot stop the next import from producing it again. Showing
 * such a tag as an ordinary category is what keeps the library navigable: the pictures
 * are reachable, filterable and movable instead of sitting in a name no surface lists.
 */
function stickerCategories() {
  const out = [];
  for (const name of stickerUI.categories) {
    const trimmed = String(name || '').trim();
    if (!trimmed || trimmed === UNCATEGORIZED || out.includes(trimmed)) continue;
    out.push(trimmed);
  }
  for (const row of stickerUI.index) {
    const tag = stickerTagOf(row);
    if (tag === UNCATEGORIZED || out.includes(tag)) continue;
    out.push(tag);
  }
  return out;
}

/**
 * Parses the stored category list, or null when there is nothing to parse.
 *
 * A garbage value returns null and is REPLACED with the ten defaults: the list is small
 * and reproducible, unlike the index, so recovering from a corrupt one by re-seeding is
 * strictly better than offering an empty list nobody can add to (every add would still
 * work, but the user would silently lose the ten names the model uses).
 */
function parseStoredCategories(raw) {
  let parsed = null;
  try {
    parsed = JSON.parse(String(raw || ''));
  } catch {
    return null;
  }
  if (!Array.isArray(parsed)) return null;
  const out = [];
  for (const item of parsed) {
    const name = String(item === undefined || item === null ? '' : item).trim();
    if (!name || name === UNCATEGORIZED || out.includes(name)) continue;
    out.push(name);
  }
  return out;
}

async function saveStickerCategories() {
  await request('storage.set', {
    key: CATEGORIES_KEY,
    value: JSON.stringify(stickerUI.categories),
  });
}

/** Writes the whole index. One key, so a batch edit is ONE write. */
async function saveStickerIndex() {
  await request('storage.set', {
    key: STICKERS_KEY,
    value: JSON.stringify(stickerUI.index),
  });
}

/** Reads both keys and seeds the category list on first run. */
async function loadStickerLibrary() {
  const [indexRes, catRes] = await Promise.all([
    request('storage.get', { key: STICKERS_KEY }),
    request('storage.get', { key: CATEGORIES_KEY }),
  ]);
  const rows = [];
  try {
    const parsed = JSON.parse(String((indexRes && indexRes.value) || '[]'));
    for (const row of Array.isArray(parsed) ? parsed : []) {
      if (!row || typeof row !== 'object' || !row.hash) continue;
      rows.push({
        hash: String(row.hash),
        tag: stickerTagOf(row),
        description: String(row.description || ''),
      });
    }
  } catch {
    /* an unreadable index is an empty library, not a crash: the importer rewrites it */
  }
  stickerUI.index = rows;

  let categories = parseStoredCategories((catRes && catRes.value) || '');
  let seed = false;
  if (!categories) {
    categories = [...STICKER_TAGS];
    seed = true;
  }
  stickerUI.categories = categories;
  stickerUI.loaded = true;
  if (seed) await saveStickerCategories();
}

/**
 * Admits or refuses one category name.
 *
 * Add and rename share it deliberately: a rule that only one of them applied would make
 * a category creatable but not renamable, which is the kind of asymmetry nobody reports
 * and everybody works around.
 */
function checkStickerCategoryName(raw, except) {
  const name = String(raw === undefined || raw === null ? '' : raw).trim();
  if (!name) return { ok: false, error: '分类名不能为空' };
  if (name === UNCATEGORIZED) {
    return { ok: false, error: `「${UNCATEGORIZED}」是内建分类，不能拿它当分类名` };
  }
  if (Array.from(name).length > STICKER_TAG_MAX_CHARS) {
    return { ok: false, error: `分类名最多 ${STICKER_TAG_MAX_CHARS} 个字符` };
  }
  if (name !== except && stickerCategories().includes(name)) {
    return { ok: false, error: `分类「${name}」已经存在` };
  }
  return { ok: true, name };
}

/** Shows one line in the sticker card's own status area (and in the log for the rest). */
function stickerSay(text, tone) {
  if (!els.stickerStatus) return;
  els.stickerStatus.textContent = text || '';
  els.stickerStatus.hidden = !text;
  els.stickerStatus.dataset.tone = tone || 'info';
}

/** Adds one category. Empty / duplicate / too long / the reserved name are refused. */
async function addStickerCategory(raw) {
  const verdict = checkStickerCategoryName(raw);
  if (!verdict.ok) {
    stickerSay(`新增分类失败：${verdict.error}`, 'warn');
    note(`表情包分类新增失败：${verdict.error}`);
    return false;
  }
  stickerUI.categories.push(verdict.name);
  await saveStickerCategories();
  stickerUI.editing = '';
  stickerSay(`已新增分类「${verdict.name}」`, 'ok');
  note(`新增表情包分类「${verdict.name}」`);
  renderStickerSection();
  return true;
}

/**
 * Renames one category and migrates the index rows that carry the old name.
 *
 * Both halves are needed: leaving the rows behind would make every renamed sticker fall
 * out of the new category and reappear as a discovered tag with the OLD name - the
 * "分类漂移" this whole section exists to prevent.
 */
async function renameStickerCategory(from, raw) {
  const old = String(from || '').trim();
  if (!old || old === UNCATEGORIZED) {
    stickerSay(`「${UNCATEGORIZED}」是内建分类，不能改名`, 'warn');
    note('表情包分类改名失败：「未分类」是内建分类');
    return false;
  }
  const verdict = checkStickerCategoryName(raw, old);
  if (!verdict.ok) {
    stickerSay(`改名失败：${verdict.error}`, 'warn');
    note(`表情包分类改名失败：${verdict.error}`);
    return false;
  }
  if (verdict.name === old) {
    stickerUI.editing = '';
    renderStickerSection();
    return true;
  }
  let moved = 0;
  for (const row of stickerUI.index) {
    if (stickerTagOf(row) !== old) continue;
    row.tag = verdict.name;
    moved += 1;
  }
  const at = stickerUI.categories.indexOf(old);
  if (at >= 0) stickerUI.categories[at] = verdict.name;
  await saveStickerCategories();
  if (moved) await saveStickerIndex();
  if (stickerUI.filter === old) stickerUI.filter = verdict.name;
  if (stickerUI.moveTarget === old) stickerUI.moveTarget = verdict.name;
  stickerUI.editing = '';
  stickerSay(`「${old}」已改名为「${verdict.name}」，${moved} 张随之迁移`, 'ok');
  note(`表情包分类「${old}」已改名为「${verdict.name}」，${moved} 张随之迁移`);
  renderStickerSection();
  return true;
}

/**
 * Removes one category from the list, and re-files its stickers under 未分类.
 *
 * THE BYTES ARE NOT TOUCHED. No `storage.remove`, no `sticker_<hash>` write: a category
 * is a LABEL, and "I deleted a label" must never destroy pictures the user sent to the
 * bot. The index rows keep their hash, so the pictures stay usable - and stay reachable
 * from the 未分类 bucket, which is why that bucket cannot be deleted or renamed.
 */
async function deleteStickerCategory(name) {
  const target = String(name || '').trim();
  if (!target || target === UNCATEGORIZED) {
    stickerSay(`「${UNCATEGORIZED}」是内建分类，不能删除`, 'warn');
    note('表情包分类删除失败：「未分类」是内建分类');
    return false;
  }
  let moved = 0;
  for (const row of stickerUI.index) {
    if (stickerTagOf(row) !== target) continue;
    row.tag = UNCATEGORIZED;
    moved += 1;
  }
  stickerUI.categories = stickerUI.categories.filter((item) => item !== target);
  await saveStickerCategories();
  if (moved) await saveStickerIndex();
  if (stickerUI.filter === target) stickerUI.filter = UNCATEGORIZED;
  if (stickerUI.moveTarget === target) stickerUI.moveTarget = UNCATEGORIZED;
  stickerSay(`分类「${target}」已删除，${moved} 张归入${UNCATEGORIZED}`, 'ok');
  note(`表情包分类「${target}」已删除，${moved} 张归入${UNCATEGORIZED}`);
  renderStickerSection();
  return true;
}

/** Moves every ticked sticker to one category, in a single index write. */
async function moveSelectedStickers(targetRaw) {
  const target = String(targetRaw || '').trim() || UNCATEGORIZED;
  if (!stickerUI.selected.size) {
    stickerSay('先在下面勾选要移动的表情包', 'warn');
    return false;
  }
  const picked = new Set(stickerUI.selected);
  let moved = 0;
  for (const row of stickerUI.index) {
    if (!picked.has(row.hash)) continue;
    if (stickerTagOf(row) === target) continue;
    row.tag = target;
    moved += 1;
  }
  if (!moved) {
    stickerSay(`所选表情包已经都在「${target}」里了`, 'warn');
    return false;
  }
  await saveStickerIndex();
  stickerUI.selected.clear();
  stickerSay(`已把 ${moved} 张表情包移到「${target}」`, 'ok');
  note(`已把 ${moved} 张表情包移到「${target}」`);
  renderStickerSection();
  return true;
}

/** The rows of the current page after the filter, plus the paging arithmetic. */
function stickerPage() {
  const filter = stickerUI.filter;
  const matched = stickerUI.index.filter(
    (row) => filter === STICKER_FILTER_ALL || stickerTagOf(row) === filter,
  );
  const pages = Math.max(1, Math.ceil(matched.length / STICKER_PAGE_SIZE));
  const page = Math.min(Math.max(1, stickerUI.page), pages);
  stickerUI.page = page;
  const start = (page - 1) * STICKER_PAGE_SIZE;
  return {
    rows: matched.slice(start, start + STICKER_PAGE_SIZE),
    total: matched.length,
    pages,
    page,
  };
}

/** Replaces a <select>'s options, keeping the current choice when it still exists. */
function fillStickerSelect(el, options, selected) {
  if (!el) return;
  el.replaceChildren();
  for (const option of options) {
    const node = document.createElement('option');
    node.value = option;
    node.textContent = option;
    node.selected = option === selected;
    el.appendChild(node);
  }
  el.value = options.includes(selected) ? selected : (options[0] || '');
}

/**
 * Reads the CURRENT PAGE's bytes only.
 *
 * `storage.get` per hash, not one bulk call: the host's storage API is per key, and the
 * point of this function is that a 100-image library costs 24 reads, not 100.
 */
async function loadStickerPageBytes(rows) {
  if (!granted.has('storage')) return;
  const token = ++stickerUI.loadToken;
  const wanted = new Set(rows.map((row) => row.hash));
  // Drop copies of pages the user has left. Without this a browse through the whole
  // library would leave every image base64-resident in a tab that shows 24 at a time.
  if (stickerUI.bytes.size > STICKER_PAGE_SIZE * 3) {
    for (const hash of [...stickerUI.bytes.keys()]) {
      if (!wanted.has(hash)) stickerUI.bytes.delete(hash);
    }
  }
  for (const row of rows) {
    // A page rendered while this loop was awaiting has taken over: the user paged on.
    if (token !== stickerUI.loadToken) return;
    if (stickerUI.bytes.has(row.hash)) continue;
    try {
      const res = await request('storage.get', { key: `${STICKER_BYTES_PREFIX}${row.hash}` });
      const base64 = String((res && res.value) || '');
      if (!base64) continue;
      stickerUI.bytes.set(row.hash, base64);
      paintStickerThumb(row.hash);
    } catch (err) {
      note(`读取表情包图片失败：${(err && err.message) || err}`);
    }
  }
}

/** Fills one already-rendered <img> from the byte cache, with the sniffed MIME type. */
function paintStickerThumb(hash) {
  if (!els.stickerGrid) return;
  if (!/^[0-9A-Za-z_-]+$/.test(hash)) return;
  const img = els.stickerGrid.querySelector(`img[data-hash="${hash}"]`);
  const base64 = stickerUI.bytes.get(hash);
  if (!img || !base64) return;
  img.src = `data:${stickerMime(base64)};base64,${base64}`;
  img.dataset.loaded = '1';
}

/** The "3 / 8 selected" line and the select-all box, from the current selection. */
function updateStickerSelection(page) {
  const current = page || stickerPage();
  const hashes = current.rows.map((row) => row.hash);
  const chosen = hashes.filter((hash) => stickerUI.selected.has(hash)).length;
  if (els.stickerSelected) {
    els.stickerSelected.textContent = stickerUI.selected.size
      ? `已选 ${stickerUI.selected.size} 张（本页 ${chosen} 张）`
      : '未选中';
  }
  if (els.stickerSelectPage) {
    els.stickerSelectPage.checked = hashes.length > 0 && chosen === hashes.length;
    els.stickerSelectPage.indeterminate = chosen > 0 && chosen < hashes.length;
  }
}

/** One row of the category list: the built-in bucket, or a name with 改名 / 删除. */
function stickerCategoryRow(item, count) {
  const li = document.createElement('li');
  li.dataset.category = item.name;
  if (!item.builtin && stickerUI.editing === item.name) {
    const input = document.createElement('input');
    input.type = 'text';
    input.className = 'cat-input';
    input.value = item.name;
    const save = document.createElement('button');
    save.type = 'button';
    save.className = 'ghost';
    save.dataset.action = 'rename-save';
    save.textContent = '保存';
    save.addEventListener('click', () => void renameStickerCategory(item.name, input.value));
    input.addEventListener('keydown', (event) => {
      if (event.key === 'Enter') void renameStickerCategory(item.name, input.value);
      if (event.key === 'Escape') {
        stickerUI.editing = '';
        renderStickerSection();
      }
    });
    const cancel = document.createElement('button');
    cancel.type = 'button';
    cancel.className = 'ghost';
    cancel.dataset.action = 'rename-cancel';
    cancel.textContent = '取消';
    cancel.addEventListener('click', () => {
      stickerUI.editing = '';
      renderStickerSection();
    });
    const counter = document.createElement('span');
    counter.className = 'cat-count';
    counter.textContent = `${count} 张`;
    li.append(input, save, cancel, counter);
    return li;
  }

  const name = document.createElement('span');
  name.className = 'cat-name';
  name.textContent = item.name;
  const counter = document.createElement('span');
  counter.className = 'cat-count';
  counter.textContent = `${count} 张`;
  li.append(name, counter);
  if (item.builtin) {
    const hint = document.createElement('span');
    hint.className = 'cat-builtin';
    hint.textContent = '内建，不可改名/删除';
    li.appendChild(hint);
    return li;
  }
  const rename = document.createElement('button');
  rename.type = 'button';
  rename.className = 'ghost';
  rename.dataset.action = 'rename';
  rename.dataset.category = item.name;
  rename.textContent = '改名';
  rename.addEventListener('click', () => {
    stickerUI.editing = item.name;
    renderStickerSection();
  });
  const remove = document.createElement('button');
  remove.type = 'button';
  remove.className = 'ghost';
  remove.dataset.action = 'delete';
  remove.dataset.category = item.name;
  remove.textContent = '删除';
  remove.addEventListener('click', () => void deleteStickerCategory(item.name));
  li.append(rename, remove);
  return li;
}

/** Draws the whole sticker card from `stickerUI` (no storage reads happen here). */
function renderStickerSection() {
  if (view !== 'workshop' || !els.stickerGrid) return;
  const categories = stickerCategories();
  if (
    stickerUI.filter !== STICKER_FILTER_ALL &&
    stickerUI.filter !== UNCATEGORIZED &&
    !categories.includes(stickerUI.filter)
  ) {
    stickerUI.filter = STICKER_FILTER_ALL;
  }
  const page = stickerPage();

  if (els.stickerSummary) {
    const scope = stickerUI.filter === STICKER_FILTER_ALL ? '全部' : stickerUI.filter;
    els.stickerSummary.textContent =
      `共 ${stickerUI.index.length} 张表情包（${scope} ${page.total} 张）·` +
      ` 第 ${page.page} / ${page.pages} 页`;
  }

  fillStickerSelect(
    els.stickerFilter,
    [STICKER_FILTER_ALL, ...categories, UNCATEGORIZED],
    stickerUI.filter,
  );
  const moveOptions = [...categories, UNCATEGORIZED];
  if (!moveOptions.includes(stickerUI.moveTarget)) stickerUI.moveTarget = UNCATEGORIZED;
  fillStickerSelect(els.stickerMoveTarget, moveOptions, stickerUI.moveTarget);
  stickerUI.moveTarget = els.stickerMoveTarget
    ? els.stickerMoveTarget.value
    : stickerUI.moveTarget;

  els.stickerGrid.replaceChildren();
  els.stickerGrid.hidden = page.rows.length === 0;
  for (const row of page.rows) {
    const cell = document.createElement('div');
    cell.className = 'sticker-cell';
    cell.dataset.hash = row.hash;
    if (stickerUI.selected.has(row.hash)) cell.classList.add('is-selected');

    const img = document.createElement('img');
    img.className = 'sticker-thumb';
    img.dataset.hash = row.hash;
    img.alt = row.description || '表情包';
    const tooltip = `${stickerTagOf(row)}${row.description ? '：' + row.description : ''}`;
    img.title = tooltip;
    const cached = stickerUI.bytes.get(row.hash);
    if (cached) img.src = `data:${stickerMime(cached)};base64,${cached}`;

    const tools = document.createElement('div');
    tools.className = 'sticker-row';
    const pick = document.createElement('label');
    pick.className = 'sticker-pick';
    const box = document.createElement('input');
    box.type = 'checkbox';
    box.className = 'sticker-check';
    box.dataset.hash = row.hash;
    box.checked = stickerUI.selected.has(row.hash);
    box.title = '勾选后可批量改分类';
    box.addEventListener('change', () => {
      if (box.checked) stickerUI.selected.add(row.hash);
      else stickerUI.selected.delete(row.hash);
      cell.classList.toggle('is-selected', box.checked);
      updateStickerSelection(page);
    });
    pick.appendChild(box);
    const badge = document.createElement('span');
    badge.className = 'sticker-badge';
    badge.textContent = stickerTagOf(row);
    badge.title = tooltip;
    tools.append(pick, badge);

    const desc = document.createElement('p');
    desc.className = 'sticker-desc';
    desc.textContent = row.description || '（没有描述）';
    desc.title = tooltip;

    cell.append(img, tools, desc);
    els.stickerGrid.appendChild(cell);
  }
  if (els.stickerEmpty) els.stickerEmpty.hidden = page.rows.length !== 0;
  // Only this page's bytes, and only when there is a page to paint.
  if (page.rows.length) void loadStickerPageBytes(page.rows);

  if (els.stickerPage) els.stickerPage.textContent = `第 ${page.page} / ${page.pages} 页`;
  if (els.stickerPrev) els.stickerPrev.disabled = page.page <= 1;
  if (els.stickerNext) els.stickerNext.disabled = page.page >= page.pages;

  if (els.stickerCategories) {
    els.stickerCategories.replaceChildren();
    const counts = new Map();
    for (const row of stickerUI.index) {
      const tag = stickerTagOf(row);
      counts.set(tag, (counts.get(tag) || 0) + 1);
    }
    const rows = [
      { name: UNCATEGORIZED, builtin: true },
      ...categories.map((name) => ({ name, builtin: false })),
    ];
    for (const item of rows) {
      els.stickerCategories.appendChild(stickerCategoryRow(item, counts.get(item.name) || 0));
    }
  }

  updateStickerSelection(page);
}

/** Reads the two keys and redraws the card. Called from renderWorkshop (and its poll). */
async function loadStickerSection() {
  if (!granted.has('storage') || view !== 'workshop' || !els.stickerGrid) return;
  // A rename box is open: the five-second poll must not pull the input out from under
  // the user's cursor, so this round is skipped entirely.
  if (stickerUI.editing) return;
  try {
    await loadStickerLibrary();
  } catch (err) {
    stickerSay(`读取表情包索引失败：${(err && err.message) || err}`, 'warn');
    return;
  }
  renderStickerSection();
}

/** Wires the sticker card's controls ONCE; every handler re-reads the live state. */
function bindStickerControls() {
  if (stickerUI.bound) return;
  stickerUI.bound = true;
  if (els.stickerFilter) {
    els.stickerFilter.addEventListener('change', () => {
      stickerUI.filter = els.stickerFilter.value || STICKER_FILTER_ALL;
      stickerUI.page = 1;
      stickerUI.selected.clear();
      renderStickerSection();
    });
  }
  if (els.stickerMoveTarget) {
    els.stickerMoveTarget.addEventListener('change', () => {
      stickerUI.moveTarget = els.stickerMoveTarget.value || UNCATEGORIZED;
    });
  }
  if (els.stickerMove) {
    els.stickerMove.addEventListener('click', () => {
      void moveSelectedStickers(els.stickerMoveTarget ? els.stickerMoveTarget.value : '');
    });
  }
  if (els.stickerSelectPage) {
    els.stickerSelectPage.addEventListener('change', () => {
      const page = stickerPage();
      for (const row of page.rows) {
        if (els.stickerSelectPage.checked) stickerUI.selected.add(row.hash);
        else stickerUI.selected.delete(row.hash);
      }
      renderStickerSection();
    });
  }
  if (els.stickerPrev) {
    els.stickerPrev.addEventListener('click', () => {
      stickerUI.page = Math.max(1, stickerUI.page - 1);
      renderStickerSection();
    });
  }
  if (els.stickerNext) {
    els.stickerNext.addEventListener('click', () => {
      stickerUI.page += 1;
      renderStickerSection();
    });
  }
  const submitNewCategory = () => {
    if (!els.stickerNewName) return;
    void addStickerCategory(els.stickerNewName.value).then((ok) => {
      if (ok) els.stickerNewName.value = '';
    });
  };
  if (els.stickerAdd) els.stickerAdd.addEventListener('click', submitNewCategory);
  if (els.stickerNewName) {
    els.stickerNewName.addEventListener('keydown', (event) => {
      if (event.key !== 'Enter') return;
      event.preventDefault();
      submitNewCategory();
    });
  }
}

/** Reads the files the bot wrote, so the workshop shows its state rather than its own. */
async function loadSnapshot() {
  if (!granted.has('storage')) return;
  try {
    const [status, groups, log] = await Promise.all([
      request('storage.get', { key: STATUS_KEY }),
      request('storage.get', { key: GROUPS_KEY }),
      request('storage.get', { key: LOG_KEY }),
    ]);
    if (status && status.value) {
      try {
        const parsed = JSON.parse(status.value);
        state.ws = parsed.state || state.ws;
        state.wsError = parsed.error || '';
        state.selfID = parsed.selfID || state.selfID;
        state.selfName = parsed.selfName || state.selfName;
        state.counts = parsed.counts || state.counts;
        if (els.statusNote) {
          els.statusNote.textContent = parsed.at
            ? `由桌宠进程在 ${new Date(parsed.at).toLocaleString('zh-CN', { hour12: false })} 写入。`
            : '还没有写入。';
        }
      } catch {
        /* a corrupt snapshot is not worth an error: the next write fixes it */
      }
    }
    if (groups && groups.value) {
      try {
        const parsed = JSON.parse(groups.value);
        if (Array.isArray(parsed)) {
          state.groups = new Map(parsed.map((row) => [String(row.id), row]));
        }
      } catch {
        /* ignore */
      }
    }
    if (log && log.value) {
      try {
        const parsed = JSON.parse(log.value);
        if (Array.isArray(parsed)) state.log = parsed.slice(-maxLogEntries);
      } catch {
        /* ignore */
      }
    }
  } catch (err) {
    if (els.statusNote) els.statusNote.textContent = '读取不到桌宠那边的状态。';
  }
}

async function renderWorkshop() {
  await loadSnapshot();
  // The sticker library is read here rather than on its own timer: this function is what
  // the five-second poll calls, and one round of requests per refresh is cheaper than two
  // independent pollers that could paint a half-updated card.
  await loadStickerSection();
  let values = {};
  if (granted.has('plugin.config')) {
    try {
      const res = await request('config.get', {});
      values = (res && res.values) || {};
    } catch (err) {
      /* the facts below fall back to the manifest defaults */
    }
  }
  renderFacts({ ...DEFAULTS, ...values });
  setChip(els.chipState, STATE_LABEL[state.ws] || state.ws, state.ws);
  setChip(
    els.chipSelf,
    state.selfID ? `机器人：${state.selfName || state.selfID}` : '机器人：未知',
  );
  setChip(els.chipModel, `模型：${state.modelSource || (values.llmModel || '未知')}`);
  if (els.statusError) {
    els.statusError.hidden = !state.wsError;
    els.statusError.textContent = state.wsError ? `最近一次错误：${state.wsError}` : '';
  }
  renderGroups();
  renderLog();
}

// --- message pump ------------------------------------------------------------

function onResponse(data) {
  const waiter = pending.get(data.id);
  if (!waiter) return;
  pending.delete(data.id);
  if (data.ok) {
    waiter.resolve(data.result);
  } else {
    waiter.reject(new Error(data.error || '插件请求失败'));
  }
}

function onEvent(data) {
  if (!data || typeof data.name !== 'string') return;
  switch (data.name) {
    case 'ws.message':
      if (view === 'background' && data.payload && typeof data.payload.text === 'string') {
        onSocketFrame(data.payload.text);
      }
      break;
    case 'ws.state':
      if (view === 'background') onSocketState(data.payload);
      break;
    case 'llm.delta':
      // Nothing streams into the group: a chat protocol has no "partial message",
      // so the reply is sent once, when it is finished.
      break;
    default:
      break;
  }
}

function onInit(payload) {
  self = { pluginId: payload.pluginId || '', surface: payload.surface || {} };
  applyTheme(payload.theme);
  granted.clear();
  for (const name of payload.granted || []) granted.add(name);
  applyView(self.surface);
  if (view === 'background') {
    void startBot();
  } else {
    void renderWorkshop();
    // The workshop is a second process's view of the same files, so it refreshes
    // while it is open; the bot itself does not poll anything.
    setInterval(() => void renderWorkshop(), 5000);
  }
}

/**
 * Applies the window's colour scheme.
 *
 * The market program owns the scheme; this document only mirrors it, because it is a
 * sandboxed frame that cannot see the host's CSS. `data-theme` on <html> is the whole
 * interface to style.css, which holds both palettes.
 *
 * Three ways the value arrives, in the order they can happen:
 *   - on the frame URL, applied by the inline script in panel.html BEFORE the first
 *     paint (no flash of the wrong scheme);
 *   - in `init`, for a document mounted without it;
 *   - in a `theme` message, when the user flips the switch while this frame runs.
 */
function applyTheme(theme) {
  document.documentElement.dataset.theme = theme === 'light' ? 'light' : 'dark';
}

// The pet mounts this document too, without a scheme; dark is what it has always
// been there.
applyTheme(new URLSearchParams(location.search).get('theme'));

function onMessage(event) {
  if (event.source !== window.parent) return;
  const data = event.data;
  if (!data || typeof data !== 'object' || data.v !== PROTOCOL) return;
  switch (data.type) {
    case 'init':
      onInit(data);
      break;
    case 'theme':
      applyTheme(data.theme);
      break;
    case 'response':
      onResponse(data);
      break;
    case 'event':
      onEvent(data);
      break;
    default:
      break;
  }
}

window.addEventListener('message', onMessage);
postToHost({ type: 'ready' });

/**
 * Test seam: one bridge round, and the live state.
 *
 * The bridge runs on a 5 s timer, and a test that waited for real seconds would be slow
 * and flaky. Publishing the tick lets the behaviour be driven directly - the alternative,
 * putting the interval on a fake clock, would also fake out the WebSocket retry ladder
 * that the other tests depend on.
 *
 * It is NOT a capability: everything it calls still goes through `request`, i.e. through
 * the dispatcher's permission gate.
 */
window.__qq = Object.freeze({ bridgeTick: pollBridge, state, ffmpegBudgetMs });

// --- 从导入的图库里挑一张发出去 ------------------------------------------------

/**
 * The MIME type of a base64 image, sniffed from its first bytes.
 *
 * Needed because the importer stored BYTES: net.fetch returns a base64 body with no
 * content-type, and `data:` URIs must carry one. A GIF announced as image/png is
 * rejected by some protocol sides and silently broken by others.
 */
function stickerMime(base64) {
  const head = String(base64 || '').slice(0, 16);
  if (head.startsWith('iVBORw0KGgo')) return 'image/png';
  if (head.startsWith('/9j/')) return 'image/jpeg';
  if (head.startsWith('R0lGOD')) return 'image/gif';
  if (head.startsWith('UklGR')) return 'image/webp';
  return 'image/png';
}

/**
 * Picks a sticker for this mood: the imported library first, the URL list as fallback.
 *
 * Matching is by category only, and a mood with no stickers yields NOTHING rather than
 * a random unrelated picture - a "无语" reply illustrated with someone's celebratory
 * gif is worse than no sticker at all.
 */
async function pickStickerForTag(tag, urlLibrary) {
  try {
    const index = await loadStickerIndex();
    const matches = index.filter((row) => row.tag === tag);
    if (matches.length) {
      const row = matches[Math.floor(Math.random() * matches.length)];
      const res = await request('storage.get', { key: `sticker_${row.hash}` });
      const base64 = String((res && res.value) || '');
      if (base64) {
        // Yogurt rejects the `data:` scheme outright ("Unsupported URI scheme"), so the
        // bytes go out as a OneBot-style `base64://` payload instead.
        return { uri: `base64://${base64}`, kind: `library` };
      }
    }
  } catch (err) {
    note(`读取图库失败：${(err && err.message) || err}`);
  }
  if (urlLibrary && urlLibrary.length) {
    return { uri: urlLibrary[Math.floor(Math.random() * urlLibrary.length)], kind: 'url' };
  }
  return null;
}

// The sticker card's controls are wired once, at load. Function declarations are hoisted,
// so this can sit at the end of the file while the handlers live with the rest of the
// workshop code above.
bindStickerControls();

